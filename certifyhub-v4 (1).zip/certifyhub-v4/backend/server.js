const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const http = require('http');
const socketIO = require('socket.io');
const path = require('path');
require('dotenv').config();

const app = express();
const server = http.createServer(app);
const io = socketIO(server, {
  cors: {
    origin: process.env.CLIENT_URL || 'http://localhost:3000',
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    credentials: true
  }
});

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

mongoose.connect(process.env.MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => console.log('✅ MongoDB connected'))
.catch(err => console.error('❌ MongoDB error:', err));

const User = require('./models/User');
const Certificate = require('./models/Certificate');

const connectedUsers = new Map();

io.on('connection', (socket) => {
  console.log('🔌 Client connected:', socket.id);

  socket.on('user:join', (userId) => {
    connectedUsers.set(userId, socket.id);
    socket.userId = userId;
    console.log(`👤 User ${userId} joined`);
  });

  socket.on('disconnect', () => {
    if (socket.userId) {
      connectedUsers.delete(socket.userId);
    }
  });

  socket.on('notification:read', async ({ userId, notificationId }) => {
    try {
      const user = await User.findById(userId);
      if (user) {
        const notif = user.notifications.id(notificationId);
        if (notif) { notif.isRead = true; await user.save(); }
        socket.emit('notification:updated', { notificationId, isRead: true });
      }
    } catch (e) { console.error(e); }
  });

  socket.on('notification:read-all', async ({ userId }) => {
    try {
      const user = await User.findById(userId);
      if (user) {
        user.notifications.forEach(n => { n.isRead = true; });
        await user.save();
        socket.emit('notification:all-read');
      }
    } catch (e) { console.error(e); }
  });

  socket.on('notification:delete', async ({ userId, notificationId }) => {
    try {
      const user = await User.findById(userId);
      if (user) {
        user.notifications = user.notifications.filter(n => n._id.toString() !== notificationId);
        await user.save();
        socket.emit('notification:deleted', { notificationId });
      }
    } catch (e) { console.error(e); }
  });
});

app.set('io', io);
app.set('connectedUsers', connectedUsers);

// ── FIXED: Notify only dept-matched teachers ──
async function sendNotificationToTeachers(certificate) {
  try {
    if (!certificate.student.name) {
      await certificate.populate('student', 'name rollNumber department');
    }

    const studentDept = certificate.student.department;

    // Find teachers whose department matches the student's department
    let teacherQuery = { role: 'teacher', isApproved: true };
    if (studentDept) {
      teacherQuery.department = { $regex: new RegExp(`^${studentDept}$`, 'i') };
    }

    let teachers = await User.find(teacherQuery);

    // If no dept-matched teachers found, fall back to all teachers
    if (teachers.length === 0) {
      teachers = await User.find({ role: 'teacher', isApproved: true });
    }

    const notification = {
      message: `${certificate.student.name} uploaded "${certificate.title}"`,
      certificateId: certificate._id,
      studentName: certificate.student.name,
      studentDept: studentDept || '',
      isRead: false,
      createdAt: new Date()
    };

    for (const teacher of teachers) {
      // Keep max 50 notifications
      if (teacher.notifications.length >= 50) {
        teacher.notifications = teacher.notifications.slice(-49);
      }
      teacher.notifications.push(notification);
      await teacher.save();

      const socketId = connectedUsers.get(teacher._id.toString());
      if (socketId) {
        const savedNotif = teacher.notifications[teacher.notifications.length - 1];
        io.to(socketId).emit('notification:new', {
          notification: savedNotif,
          unreadCount: teacher.notifications.filter(n => !n.isRead).length
        });
      }
    }

    console.log(`✉️ Sent to ${teachers.length} teacher(s) in dept: ${studentDept || 'all'}`);
  } catch (error) {
    console.error('Error sending notifications:', error);
  }
}

app.set('sendNotificationToTeachers', sendNotificationToTeachers);

// Routes
app.use('/api/auth', require('./routes/auth'));
app.use('/api/certificates', require('./routes/certificates'));
app.use('/api/admin', require('./routes/admin'));
app.use('/api/ml', require('./routes/ml'));
app.use('/api/feedback', require('./routes/feedback'));

// Notification routes
const notificationRouter = express.Router();
const { auth } = require('./middleware/auth');

notificationRouter.get('/', auth, async (req, res) => {
  try {
    const user = await User.findById(req.userId).select('notifications');
    res.json({
      notifications: user.notifications.sort((a, b) => b.createdAt - a.createdAt),
      unreadCount: user.notifications.filter(n => !n.isRead).length
    });
  } catch (e) { res.status(500).json({ error: 'Server error' }); }
});

notificationRouter.put('/:id/read', auth, async (req, res) => {
  try {
    const user = await User.findById(req.userId);
    const notif = user.notifications.id(req.params.id);
    if (notif) { notif.isRead = true; await user.save(); }
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: 'Server error' }); }
});

notificationRouter.put('/read-all', auth, async (req, res) => {
  try {
    await User.updateOne(
      { _id: req.userId },
      { $set: { 'notifications.$[].isRead': true } }
    );
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: 'Server error' }); }
});

notificationRouter.delete('/:id', auth, async (req, res) => {
  try {
    await User.updateOne(
      { _id: req.userId },
      { $pull: { notifications: { _id: req.params.id } } }
    );
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: 'Server error' }); }
});

notificationRouter.delete('/clear-all', auth, async (req, res) => {
  try {
    await User.updateOne({ _id: req.userId }, { $set: { notifications: [] } });
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: 'Server error' }); }
});

app.use('/api/notifications', notificationRouter);

app.get('/health', (req, res) => res.json({ status: 'OK', timestamp: new Date() }));
app.use((req, res) => res.status(404).json({ error: 'Route not found' }));
app.use((err, req, res, next) => res.status(500).json({ error: 'Internal server error' }));

const PORT = process.env.PORT || 5000;
server.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));

module.exports = { app, io };
