const express = require('express');
const router = express.Router();
const Certificate = require('../models/Certificate');
const User = require('../models/User');
const { auth, studentOnly, teacherOrAdmin, adminOnly } = require('../middleware/auth');
const upload = require('../middleware/upload');
const { extractKeywords, categorizeCertificate, determineSkillLevel, searchCertificates } = require('../services/nlpService');
const { verifyCertificate, manualVerification } = require('../services/verificationService');
const path = require('path');
const fs = require('fs');

// Upload certificate (Students only)
router.post('/upload', auth, studentOnly, upload.single('certificate'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'Please upload a certificate file' });
    }
    
    const { title, description, issueDate, certificateId, issuer, qrCodeData } = req.body;
    
    // Validate required fields
    if (!title || !description || !issueDate) {
      // Delete uploaded file if validation fails
      fs.unlinkSync(req.file.path);
      return res.status(400).json({ error: 'Please provide title, description, and issue date' });
    }
    
    // NLP Processing
    const keywords = extractKeywords(`${title} ${description}`);
    const category = categorizeCertificate(title, description);
    const skillLevel = determineSkillLevel(title, description);
    
    // Create certificate
    const certificate = new Certificate({
      student: req.userId,
      title,
      description,
      issueDate: new Date(issueDate),
      fileName: req.file.filename,
      filePath: req.file.path,
      fileType: req.file.mimetype,
      certificateId: certificateId || '',
      issuer: issuer || '',
      qrCodeData: qrCodeData || '',
      category,
      keywords,
      skillLevel
    });
    
    // Attempt verification if data provided
    if ((certificateId && issuer) || qrCodeData) {
      try {
        const verification = await verifyCertificate({ certificateId, issuer, qrCodeData });
        certificate.verificationStatus = verification.status;
        certificate.verificationMethod = verification.method;
        if (verification.verifiedAt) {
          certificate.verifiedAt = verification.verifiedAt;
        }
      } catch (error) {
        console.error('Verification error:', error);
      }
    }
    
    await certificate.save();
    
    // Populate student info for notification
    await certificate.populate('student', 'name rollNumber department');
    
    // Notify teachers directly
    const sendNotificationToTeachers = req.app.get('sendNotificationToTeachers');
    if (sendNotificationToTeachers) {
      sendNotificationToTeachers(certificate).catch(err => console.error('Notification error:', err));
    }

    res.status(201).json({
      message: 'Certificate uploaded successfully',
      certificate: certificate.toObject()
    });
  } catch (error) {
    console.error('Upload error:', error);
    if (req.file) {
      fs.unlinkSync(req.file.path);
    }
    res.status(500).json({ error: 'Server error during upload' });
  }
});

// Get student's own certificates
router.get('/my-certificates', auth, studentOnly, async (req, res) => {
  try {
    const certificates = await Certificate.find({ student: req.userId })
      .sort({ issueDate: -1 })
      .select('-filePath');
    
    res.json({ 
      certificates,
      count: certificates.length
    });
  } catch (error) {
    console.error('Get certificates error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Get all certificates (Teachers and Admins)
router.get('/all', auth, teacherOrAdmin, async (req, res) => {
  try {
    const { year, month, verificationStatus, studentId } = req.query;
    
    let query = {};
    
    // Filter by student (if specified)
    if (studentId) {
      query.student = studentId;
    } else if (req.userRole === 'teacher') {
      // Teachers only see certificates from students in their department
      const teacher = req.user;
      const teacherDepartment = teacher.department || teacher.subject;
      if (teacherDepartment) {
        const deptStudents = await User.find({ 
          role: 'student', 
          isApproved: true,
          department: { $regex: new RegExp(`^${teacherDepartment}$`, 'i') }
        }).select('_id');
        query.student = { $in: deptStudents.map(s => s._id) };
      }
    }
    
    // Filter by year and month (issue date)
    if (year && year !== 'all') {
      if (month && month !== 'all') {
        const monthNum = parseInt(month);
        const startDate = new Date(parseInt(year), monthNum - 1, 1);
        const endDate = new Date(parseInt(year), monthNum, 0, 23, 59, 59);
        query.issueDate = { $gte: startDate, $lte: endDate };
      } else {
        const startDate = new Date(`${year}-01-01`);
        const endDate = new Date(`${year}-12-31`);
        query.issueDate = { $gte: startDate, $lte: endDate };
      }
    } else if (month && month !== 'all') {
      // month filter without year - filter across all years for that month
      query.$expr = { $eq: [{ $month: '$issueDate' }, parseInt(month)] };
    }
    
    // Filter by verification status
    if (verificationStatus && verificationStatus !== 'all') {
      query.verificationStatus = verificationStatus;
    }
    
    const certificates = await Certificate.find(query)
      .populate('student', 'name rollNumber department')
      .sort({ issueDate: -1 })
      .select('-filePath');
    
    res.json({ 
      certificates,
      count: certificates.length
    });
  } catch (error) {
    console.error('Get all certificates error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Search certificates (NLP-powered)
router.get('/search', auth, teacherOrAdmin, async (req, res) => {
  try {
    const { query, year, verificationStatus } = req.query;
    
    // Get all certificates first
    let dbQuery = {};
    
    // Teachers only see certificates from students in their department
    if (req.userRole === 'teacher') {
      const teacher = req.user;
      const teacherDepartment = teacher.department || teacher.subject;
      if (teacherDepartment) {
        const deptStudents = await User.find({ 
          role: 'student', 
          isApproved: true,
          department: { $regex: new RegExp(`^${teacherDepartment}$`, 'i') }
        }).select('_id');
        dbQuery.student = { $in: deptStudents.map(s => s._id) };
      }
    }
    
    if (year && year !== 'all') {
      const startDate = new Date(`${year}-01-01`);
      const endDate = new Date(`${year}-12-31`);
      dbQuery.issueDate = { $gte: startDate, $lte: endDate };
    }
    
    if (verificationStatus && verificationStatus !== 'all') {
      dbQuery.verificationStatus = verificationStatus;
    }
    
    const allCertificates = await Certificate.find(dbQuery)
      .populate('student', 'name rollNumber department')
      .sort({ issueDate: -1 });
    
    // Apply NLP search if query provided
    let results = allCertificates;
    if (query && query.trim() !== '') {
      results = searchCertificates(allCertificates, query);
    }
    
    // Remove file path from results
    const sanitized = results.map(cert => {
      const { filePath, ...rest } = cert._doc || cert;
      return rest;
    });
    
    res.json({ 
      certificates: sanitized,
      count: sanitized.length,
      searchQuery: query || ''
    });
  } catch (error) {
    console.error('Search error:', error);
    res.status(500).json({ error: 'Server error during search' });
  }
});

// Download certificate
router.get('/download/:id', auth, async (req, res) => {
  try {
    const certificate = await Certificate.findById(req.params.id);
    
    if (!certificate) {
      return res.status(404).json({ error: 'Certificate not found' });
    }
    
    // Students can only download their own certificates
    if (req.userRole === 'student' && certificate.student.toString() !== req.userId.toString()) {
      return res.status(403).json({ error: 'Access denied' });
    }
    
    // Check if file exists
    if (!fs.existsSync(certificate.filePath)) {
      return res.status(404).json({ error: 'Certificate file not found' });
    }
    
    res.download(certificate.filePath, certificate.fileName);
  } catch (error) {
    console.error('Download error:', error);
    res.status(500).json({ error: 'Server error during download' });
  }
});

// View certificate inline (for preview in browser)
router.get('/view/:id', auth, async (req, res) => {
  try {
    const certificate = await Certificate.findById(req.params.id);
    
    if (!certificate) {
      return res.status(404).json({ error: 'Certificate not found' });
    }
    
    // Students can only view their own certificates
    if (req.userRole === 'student' && certificate.student.toString() !== req.userId.toString()) {
      return res.status(403).json({ error: 'Access denied' });
    }
    
    // Check if file exists
    if (!fs.existsSync(certificate.filePath)) {
      return res.status(404).json({ error: 'Certificate file not found' });
    }
    
    const mimeType = certificate.fileType || 'application/pdf';
    res.setHeader('Content-Type', mimeType);
    res.setHeader('Content-Disposition', `inline; filename="${certificate.fileName}"`);
    
    const fileStream = fs.createReadStream(certificate.filePath);
    fileStream.pipe(res);
  } catch (error) {
    console.error('View error:', error);
    res.status(500).json({ error: 'Server error during view' });
  }
});

// Delete certificate
router.delete('/:id', auth, async (req, res) => {
  try {
    const certificate = await Certificate.findById(req.params.id);
    
    if (!certificate) {
      return res.status(404).json({ error: 'Certificate not found' });
    }
    
    // Students can only delete their own, admins can delete any
    if (req.userRole === 'student' && certificate.student.toString() !== req.userId.toString()) {
      return res.status(403).json({ error: 'Access denied' });
    }
    
    // Delete file
    if (fs.existsSync(certificate.filePath)) {
      fs.unlinkSync(certificate.filePath);
    }
    
    await Certificate.findByIdAndDelete(req.params.id);
    
    res.json({ message: 'Certificate deleted successfully' });
  } catch (error) {
    console.error('Delete error:', error);
    res.status(500).json({ error: 'Server error during deletion' });
  }
});

// Manual verification (Teachers and Admins)
router.put('/verify/:id', auth, teacherOrAdmin, async (req, res) => {
  try {
    const certificate = await Certificate.findById(req.params.id);
    
    if (!certificate) {
      return res.status(404).json({ error: 'Certificate not found' });
    }
    
    const verification = manualVerification(req.userId);
    
    certificate.verificationStatus = verification.status;
    certificate.verificationMethod = verification.method;
    certificate.verifiedBy = req.userId;
    certificate.verifiedAt = verification.verifiedAt;
    
    await certificate.save();
    
    res.json({ 
      message: 'Certificate verified successfully',
      certificate
    });
  } catch (error) {
    console.error('Verification error:', error);
    res.status(500).json({ error: 'Server error during verification' });
  }
});

// Get certificate statistics (for dashboard)
router.get('/stats/overview', auth, adminOnly, async (req, res) => {
  try {
    const totalCertificates = await Certificate.countDocuments();
    const verifiedCertificates = await Certificate.countDocuments({ verificationStatus: 'verified' });
    
    const categoryCounts = await Certificate.aggregate([
      { $group: { _id: '$category', count: { $sum: 1 } } }
    ]);
    
    res.json({
      totalCertificates,
      verifiedCertificates,
      unverifiedCertificates: totalCertificates - verifiedCertificates,
      categoryCounts
    });
  } catch (error) {
    console.error('Stats error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// View certificate with token in query param — for <iframe src> and <a href> (can't send Authorization headers)
router.get('/view-token/:id', async (req, res) => {
  try {
    const jwt = require('jsonwebtoken');
    const token = req.query.token;
    if (!token) return res.status(401).json({ error: 'No token provided' });

    try {
      jwt.verify(token, process.env.JWT_SECRET);
    } catch (e) {
      return res.status(401).json({ error: 'Invalid token' });
    }

    const certificate = await Certificate.findById(req.params.id);
    if (!certificate) return res.status(404).json({ error: 'Certificate not found' });

    const fsModule = require('fs');
    if (!fsModule.existsSync(certificate.filePath)) {
      return res.status(404).json({ error: 'Certificate file not found' });
    }

    const mimeType = certificate.fileType || 'application/pdf';
    res.setHeader('Content-Type', mimeType);
    res.setHeader('Content-Disposition', `inline; filename="${certificate.fileName}"`);
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Headers', 'Authorization');

    const fileStream = fsModule.createReadStream(certificate.filePath);
    fileStream.pipe(res);
  } catch (error) {
    console.error('View-token error:', error);
    res.status(500).json({ error: 'Server error during view' });
  }
});

module.exports = router;
