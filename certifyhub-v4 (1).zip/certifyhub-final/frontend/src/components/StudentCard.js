import React, { useState } from 'react';
import { LineChart, Line, CartesianGrid, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { mlAPI } from '../services/api';
import { getErrorMessage, getScoreColor, getScoreBgColor, getPriorityColor } from '../utils/helpers';

const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#14b8a6', '#64748b'];

const StudentCard = ({ student, index, onClick }) => {
  const [showAnalysis, setShowAnalysis] = useState(false);
  const [analysis, setAnalysis] = useState(null);
  const [analysisLoading, setAnalysisLoading] = useState(false);
  const [analysisError, setAnalysisError] = useState('');

  const handleAnalysisClick = async (e) => {
    e.stopPropagation();
    setShowAnalysis(true);
    if (analysis) return;
    setAnalysisLoading(true);
    setAnalysisError('');
    try {
      const response = await mlAPI.getStudentAnalysis(student._id);
      if (response.data.hasData) {
        setAnalysis(response.data.analysis);
      } else {
        setAnalysisError(response.data.message || 'No analysis data available.');
      }
    } catch (err) {
      setAnalysisError(getErrorMessage(err));
    } finally {
      setAnalysisLoading(false);
    }
  };

  const handleCloseModal = (e) => {
    e.stopPropagation();
    setShowAnalysis(false);
  };

  const categoryData = analysis
    ? Object.entries(analysis.features.categoryCounts).map(([name, value]) => ({ name, value })).filter(i => i.value > 0)
    : [];

  return (
    <>
      <div onClick={() => onClick(student)} className="sc-card">
        {/* Header */}
        <div className="sc-header">
          <div className="sc-index">{index}</div>
          <div className="sc-cert-count">
            {student.certificateCount || 0} {student.certificateCount === 1 ? 'Cert' : 'Certs'}
          </div>
        </div>

        {/* Info */}
        <div className="sc-info">
          <h3 className="sc-name">{student.name}</h3>
          {student.rollNumber && (
            <div className="sc-detail">
              <svg className="sc-detail-icon" width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V8a2 2 0 00-2-2h-5m-4 0V5a2 2 0 114 0v1m-4 0a2 2 0 104 0m-5 8a2 2 0 100-4 2 2 0 000 4zm0 0c1.306 0 2.417.835 2.83 2M9 14a3.001 3.001 0 00-2.83 2M15 11h3m-3 4h2" />
              </svg>
              <span className="sc-detail-label">Roll No:</span>
              <span className="sc-detail-value">{student.rollNumber}</span>
            </div>
          )}
          {student.department && (
            <div className="sc-detail">
              <svg className="sc-detail-icon" width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
              </svg>
              <span className="sc-detail-label">Dept:</span>
              <span className="sc-detail-value">{student.department}</span>
            </div>
          )}
          {student.email && (
            <div className="sc-detail">
              <svg className="sc-detail-icon" width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
              </svg>
              <span className="sc-email">{student.email}</span>
            </div>
          )}
        </div>

        {/* Progress */}
        <div className="sc-progress-row">
          <span className="sc-progress-label">Total Certificates</span>
          <div className="sc-progress-right">
            {student.certificateCount > 0 ? (
              <>
                <div className="sc-progress-bar">
                  <div className="sc-progress-fill" style={{ width: `${Math.min(100, (student.certificateCount / 20) * 100)}%` }} />
                </div>
                <span className="sc-progress-num">{student.certificateCount}</span>
              </>
            ) : (
              <span className="sc-no-certs">No certificates</span>
            )}
          </div>
        </div>

        {/* AI Analysis Button */}
        <button className="sc-analysis-btn" onClick={handleAnalysisClick}>
          <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
          </svg>
          View AI Growth Analysis
        </button>

        {/* Hint */}
        <div className="sc-hint">
          Click card to view certificates
          <svg className="sc-hint-arrow" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
          </svg>
        </div>
      </div>

      {/* AI Growth Analysis Modal */}
      {showAnalysis && (
        <div className="sc-modal-overlay" onClick={handleCloseModal}>
          <div className="sc-modal" onClick={(e) => e.stopPropagation()}>
            <div className="sc-modal-header">
              <div className="sc-modal-title-row">
                <svg width="22" height="22" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                </svg>
                <div>
                  <h2 className="sc-modal-title">AI Growth Analysis</h2>
                  <p className="sc-modal-subtitle">{student.name} · Random Forest ML</p>
                </div>
              </div>
              <button className="sc-modal-close" onClick={handleCloseModal}>
                <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>

            <div className="sc-modal-body">
              {analysisLoading && (
                <div className="sc-modal-loading">
                  <div className="sc-spinner" />
                  <p>Analyzing {student.name}'s learning journey...</p>
                </div>
              )}

              {!analysisLoading && analysisError && (
                <div className="sc-modal-error">
                  <svg width="52" height="52" fill="none" stroke="#f59e0b" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                  </svg>
                  <h3>No Analysis Available</h3>
                  <p>{analysisError}</p>
                </div>
              )}

              {!analysisLoading && !analysisError && analysis && (
                <div className="sc-modal-content">
                  {/* Score Cards */}
                  <div className="sc-scores-grid">
                    <div className="sc-score-card">
                      <h4>Skill Level Score</h4>
                      <div className="sc-score-row">
                        <span className={`sc-score-num ${getScoreColor(analysis.skillLevelScore)}`}>{analysis.skillLevelScore}</span>
                        <div className="sc-score-meta"><p>out of 100</p><p>Volume, diversity & progression</p></div>
                      </div>
                      <div className="sc-score-bar-bg">
                        <div className={`sc-score-bar-fill ${getScoreBgColor(analysis.skillLevelScore)}`} style={{ width: `${analysis.skillLevelScore}%` }} />
                      </div>
                    </div>
                    <div className="sc-score-card">
                      <h4>Career Readiness Score</h4>
                      <div className="sc-score-row">
                        <span className={`sc-score-num ${getScoreColor(analysis.careerReadinessScore)}`}>{analysis.careerReadinessScore}</span>
                        <div className="sc-score-meta"><p>out of 100</p><p>Random Forest Ensemble</p></div>
                      </div>
                      <div className="sc-score-bar-bg">
                        <div className={`sc-score-bar-fill ${getScoreBgColor(analysis.careerReadinessScore)}`} style={{ width: `${analysis.careerReadinessScore}%` }} />
                      </div>
                      <div className="sc-breakdown-grid">
                        {[['Volume', analysis.careerReadinessBreakdown.volume, 25],['Diversity', analysis.careerReadinessBreakdown.diversity, 20],['Progression', analysis.careerReadinessBreakdown.progression, 25],['Consistency', analysis.careerReadinessBreakdown.consistency, 15]].map(([k,v,max]) => (
                          <div key={k} className="sc-breakdown-item"><span>{k}</span><span>{v}/{max}</span></div>
                        ))}
                        <div className="sc-breakdown-item sc-breakdown-full"><span>Specialization</span><span>{analysis.careerReadinessBreakdown.specialization}/15</span></div>
                      </div>
                    </div>
                  </div>

                  {/* Career Predictions */}
                  <div className="sc-section">
                    <h3 className="sc-section-title">Career Role Predictions</h3>
                    <div className="sc-predictions">
                      {analysis.predictedRoles.map((role, i) => (
                        <div key={i} className="sc-prediction-item">
                          <div className="sc-prediction-header">
                            <span className="sc-prediction-role">{role.role}</span>
                            <span className="sc-prediction-pct">{role.confidence}% confidence</span>
                          </div>
                          <div className="sc-score-bar-bg">
                            <div className="sc-prediction-bar" style={{ width: `${role.confidence}%` }} />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Growth Chart */}
                  <div className="sc-section">
                    <h3 className="sc-section-title">Certificate Growth Over Time</h3>
                    <ResponsiveContainer width="100%" height={220}>
                      <LineChart data={analysis.growthChart}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#f0f4ff" />
                        <XAxis dataKey="date" tick={{ fontSize: 11 }} />
                        <YAxis tick={{ fontSize: 11 }} />
                        <Tooltip />
                        <Legend />
                        <Line type="monotone" dataKey="count" stroke="#3b82f6" strokeWidth={2} name="Total Certificates" dot={{ fill: '#3b82f6', r: 4 }} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>

                  {/* Skill Distribution + Peer Comparison */}
                  <div className="sc-two-col">
                    <div className="sc-section">
                      <h3 className="sc-section-title">Skill Distribution</h3>
                      <ResponsiveContainer width="100%" height={220}>
                        <PieChart>
                          <Pie data={categoryData} cx="50%" cy="50%" labelLine={false}
                            label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                            outerRadius={75} dataKey="value">
                            {categoryData.map((entry, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                          </Pie>
                          <Tooltip />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>

                    <div className="sc-section">
                      <h3 className="sc-section-title">Peer Comparison</h3>
                      <div className="sc-peer-list">
                        {[
                          { label: "Your Certificates", val: analysis.peerComparison.userCertificates, cls: 'sc-peer-blue' },
                          { label: "Department Average", val: analysis.peerComparison.departmentAverage, cls: 'sc-peer-gray' },
                          { label: "Top Performer", val: analysis.peerComparison.topPerformer, cls: 'sc-peer-green' },
                        ].map(p => (
                          <div key={p.label} className="sc-peer-item">
                            <div className="sc-peer-header">
                              <span className="sc-peer-label">{p.label}</span>
                              <span className={`sc-peer-val ${p.cls}`}>{p.val}</span>
                            </div>
                            <div className="sc-score-bar-bg">
                              <div className={`sc-peer-bar ${p.cls}`}
                                style={{ width: `${(p.val / analysis.peerComparison.topPerformer) * 100}%` }} />
                            </div>
                          </div>
                        ))}
                        <div className="sc-ranking-box">
                          <p><span>Ranking:</span> {analysis.peerComparison.ranking}</p>
                          <p><span>Percentile:</span> {analysis.peerComparison.percentile}th</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Recommendations */}
                  <div className="sc-section">
                    <h3 className="sc-section-title">AI-Powered Recommendations</h3>
                    <div className="sc-recs">
                      {analysis.recommendations.map((rec, i) => (
                        <div key={i} className={`sc-rec-item ${getPriorityColor(rec.priority)}`}>
                          <div className="sc-rec-header">
                            <h4 className="sc-rec-skill">{rec.skill}</h4>
                            <span className={`sc-rec-priority ${getPriorityColor(rec.priority)}`}>{rec.priority} Priority</span>
                          </div>
                          <p className="sc-rec-reason">{rec.reason}</p>
                          <div className="sc-rec-time">
                            <svg width="13" height="13" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                            Estimated Time: {rec.estimatedTime}
                          </div>
                          <div className="sc-rec-suggestions">
                            <p>Suggested Topics:</p>
                            <div className="sc-rec-tags">
                              {rec.suggestions.map((s, j) => <span key={j} className="sc-rec-tag">{s}</span>)}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Learning Analytics */}
                  <div className="sc-section">
                    <h3 className="sc-section-title">Learning Analytics</h3>
                    <div className="sc-analytics-grid">
                      {[
                        { val: analysis.features.totalCertificates, label: 'Total Certificates', cls: 'sc-analytic-blue' },
                        { val: analysis.features.uniqueCategories, label: 'Unique Categories', cls: 'sc-analytic-green' },
                        { val: analysis.features.growthRate, label: 'Certs / Month', cls: 'sc-analytic-purple' },
                        { val: analysis.features.monthsActive, label: 'Months Active', cls: 'sc-analytic-orange' },
                      ].map(a => (
                        <div key={a.label} className={`sc-analytic-item ${a.cls}`}>
                          <p className="sc-analytic-val">{a.val}</p>
                          <p className="sc-analytic-label">{a.label}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default StudentCard;
