import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { certificateAPI, feedbackAPI } from '../services/api';
import { getErrorMessage } from '../utils/helpers';
import CertificateCard from '../components/CertificateCard';
import socketService from '../services/socket';

const StudentDashboard = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('certificates');
  const [certificates, setCertificates] = useState([]);
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [showUploadForm, setShowUploadForm] = useState(false);

  // Feedback state
  const [feedbacks, setFeedbacks] = useState([]);
  const [feedbackUnread, setFeedbackUnread] = useState(0);
  const [loadingFeedback, setLoadingFeedback] = useState(false);

  const [formData, setFormData] = useState({
    title: '', description: '', issueDate: '', certificateId: '', issuer: '', qrCodeData: '', file: null
  });

  useEffect(() => {
    fetchCertificates();
    fetchFeedback();

    // Real-time: new feedback from teacher arrives
    const handleNewFeedback = ({ feedback }) => {
      if (feedback) {
        setFeedbacks(prev => [feedback, ...prev]);
        setFeedbackUnread(prev => prev + 1);
      } else {
        // If feedback object not included, just refetch
        fetchFeedback();
      }
    };

    socketService.on('feedback:new', handleNewFeedback);
    return () => socketService.off('feedback:new', handleNewFeedback);
  }, []);

  const fetchCertificates = async () => {
    setLoading(true);
    try {
      const res = await certificateAPI.getMyCertificates();
      setCertificates(res.data.certificates);
    } catch (e) { setError(getErrorMessage(e)); }
    finally { setLoading(false); }
  };

  const fetchFeedback = async () => {
    setLoadingFeedback(true);
    try {
      const res = await feedbackAPI.getReceived();
      setFeedbacks(res.data.feedbacks || []);
      setFeedbackUnread(res.data.unreadCount || 0);
    } catch (e) { console.error(e); }
    finally { setLoadingFeedback(false); }
  };

  const handleMarkFeedbackRead = async (id) => {
    try {
      await feedbackAPI.markRead(id);
      setFeedbacks(prev => prev.map(f => f._id === id ? { ...f, isRead: true } : f));
      setFeedbackUnread(prev => Math.max(0, prev - 1));
    } catch (e) { console.error(e); }
  };

  const handleMarkAllFeedbackRead = async () => {
    try {
      await feedbackAPI.markAllRead();
      setFeedbacks(prev => prev.map(f => ({ ...f, isRead: true })));
      setFeedbackUnread(0);
    } catch (e) { console.error(e); }
  };

  const handleInputChange = (e) => { const { name, value } = e.target; setFormData({ ...formData, [name]: value }); };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (!['application/pdf', 'image/jpeg', 'image/jpg', 'image/png'].includes(file.type)) {
        setError('Only PDF, JPG, and PNG files are allowed'); e.target.value = ''; return;
      }
      if (file.size > 10 * 1024 * 1024) {
        setError('File size must be less than 10MB'); e.target.value = ''; return;
      }
      setFormData({ ...formData, file }); setError('');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(''); setSuccess('');
    if (!formData.title || !formData.description || !formData.issueDate || !formData.file) {
      setError('Please fill in all required fields'); return;
    }
    setUploading(true);
    try {
      const data = new FormData();
      data.append('title', formData.title);
      data.append('description', formData.description);
      data.append('issueDate', formData.issueDate);
      data.append('certificate', formData.file);
      if (formData.certificateId) data.append('certificateId', formData.certificateId);
      if (formData.issuer) data.append('issuer', formData.issuer);
      if (formData.qrCodeData) data.append('qrCodeData', formData.qrCodeData);

      await certificateAPI.upload(data);
      setSuccess('Certificate uploaded successfully! Your teacher has been notified.');
      setFormData({ title: '', description: '', issueDate: '', certificateId: '', issuer: '', qrCodeData: '', file: null });
      const fi = document.getElementById('certificate-file');
      if (fi) fi.value = '';
      setShowUploadForm(false);
      fetchCertificates();
    } catch (e) { setError(getErrorMessage(e)); }
    finally { setUploading(false); }
  };

  const handleDownload = async (certId) => {
    try {
      const res = await certificateAPI.download(certId);
      const blob = new Blob([res.data]);
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a'); a.href = url; a.download = `certificate-${certId}.pdf`; a.click();
    } catch (e) { alert(getErrorMessage(e)); }
  };

  const handleDelete = async (certId) => {
    try {
      await certificateAPI.delete(certId);
      setCertificates(prev => prev.filter(c => c._id !== certId));
      setSuccess('Certificate deleted successfully');
    } catch (e) { alert(getErrorMessage(e)); }
  };

  const verified = certificates.filter(c => c.verificationStatus === 'verified').length;
  const pending = certificates.length - verified;
  const issuers = ['', 'Coursera', 'Udemy', 'LinkedIn', 'Google', 'Microsoft', 'AWS', 'Other'];

  const typeLabels = { general: '💬 General', certificate: '📄 Certificate', encouragement: '🌟 Encouragement', improvement: '🔧 Improvement' };
  const typeColors = { general: 'fb-type-general', certificate: 'fb-type-certificate', encouragement: 'fb-type-encourage', improvement: 'fb-type-improve' };
  const formatDate = (d) => new Date(d).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });

  return (
    <div className="sd-root">
      {/* Hero header */}
      <div className="sd-hero">
        <div className="sd-hero-inner">
          <div className="sd-hero-left">
            <h1 className="sd-hero-title">My Certificates</h1>
            <p className="sd-hero-sub">Track your learning journey and achievements</p>
          </div>
          <div className="sd-hero-stats">
            {[
              { label: 'Total', val: certificates.length, color: '#6366f1' },
              { label: 'Verified', val: verified, color: '#10b981' },
              { label: 'Pending', val: pending, color: '#f59e0b' },
            ].map(s => (
              <div key={s.label} className="sd-stat-card">
                <span className="sd-stat-val" style={{ color: s.color }}>{s.val}</span>
                <span className="sd-stat-label">{s.label}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Tab bar */}
        <div className="sd-tabs">
          <button className={`sd-tab ${activeTab === 'certificates' ? 'sd-tab-active' : ''}`} onClick={() => setActiveTab('certificates')}>
            <svg width="15" height="15" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
            Certificates
          </button>
          <button className={`sd-tab ${activeTab === 'feedback' ? 'sd-tab-active' : ''}`} onClick={() => setActiveTab('feedback')}>
            <svg width="15" height="15" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
            </svg>
            Feedback Inbox
            {feedbackUnread > 0 && <span className="sd-tab-badge">{feedbackUnread}</span>}
          </button>
        </div>
      </div>

      <div className="sd-container">
        {/* ── CERTIFICATES TAB ── */}
        {activeTab === 'certificates' && (
          <>
            {error && <div className="sd-error">{error}</div>}
            {success && <div className="sd-success">{success}</div>}

            {/* Action Buttons */}
            <div className="sd-actions">
              <button onClick={() => setShowUploadForm(!showUploadForm)} className="sd-upload-btn">
                <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                </svg>
                {showUploadForm ? 'Cancel' : 'Upload Certificate'}
              </button>
              {certificates.length > 0 && (
                <button onClick={() => navigate('/ml-analysis')} className="sd-analysis-btn">
                  <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                  </svg>
                  View AI Growth Analysis
                </button>
              )}
            </div>

            {/* Upload Form */}
            {showUploadForm && (
              <div className="sd-upload-form">
                <h2 className="sd-form-title">Upload Certificate</h2>
                <form onSubmit={handleSubmit} className="sd-form-grid">
                  <div className="sd-field sd-field-full">
                    <label className="sd-label">Certificate Title <span>*</span></label>
                    <input type="text" name="title" value={formData.title} onChange={handleInputChange}
                      placeholder="e.g., Python for Data Science" className="sd-input" required />
                  </div>
                  <div className="sd-field sd-field-full">
                    <label className="sd-label">Description <span>*</span></label>
                    <textarea name="description" value={formData.description} onChange={handleInputChange}
                      placeholder="Describe what you learned" rows={3} className="sd-textarea" required />
                  </div>
                  <div className="sd-field">
                    <label className="sd-label">Issue Date <span>*</span></label>
                    <input type="date" name="issueDate" value={formData.issueDate} onChange={handleInputChange}
                      max={new Date().toISOString().split('T')[0]} className="sd-input" required />
                  </div>
                  <div className="sd-field">
                    <label className="sd-label">Issuer (Optional)</label>
                    <select name="issuer" value={formData.issuer} onChange={handleInputChange} className="sd-select">
                      {issuers.map(i => <option key={i} value={i}>{i || 'Select Issuer'}</option>)}
                    </select>
                  </div>
                  <div className="sd-field">
                    <label className="sd-label">Certificate ID (Optional)</label>
                    <input type="text" name="certificateId" value={formData.certificateId} onChange={handleInputChange}
                      placeholder="e.g., CERT123456" className="sd-input" />
                  </div>
                  <div className="sd-field">
                    <label className="sd-label">QR Code URL (Optional)</label>
                    <input type="url" name="qrCodeData" value={formData.qrCodeData} onChange={handleInputChange}
                      placeholder="https://verify.example.com/..." className="sd-input" />
                  </div>
                  <div className="sd-field sd-field-full">
                    <label className="sd-label">Certificate File (PDF/JPG/PNG, max 10MB) <span>*</span></label>
                    <input type="file" id="certificate-file" accept=".pdf,.jpg,.jpeg,.png" onChange={handleFileChange} className="sd-file-input" required />
                    {formData.file && <p className="sd-file-name">✓ {formData.file.name} ({(formData.file.size / 1024 / 1024).toFixed(2)} MB)</p>}
                  </div>
                  <div className="sd-form-buttons sd-field-full">
                    <button type="button" onClick={() => setShowUploadForm(false)} className="sd-cancel-btn">Cancel</button>
                    <button type="submit" disabled={uploading} className="sd-submit-btn">
                      {uploading ? 'Uploading...' : 'Upload Certificate'}
                    </button>
                  </div>
                </form>
              </div>
            )}

            {/* Certificates List */}
            {loading ? (
              <div className="sd-loading"><div className="sd-spinner" /><p>Loading certificates...</p></div>
            ) : certificates.length === 0 ? (
              <div className="sd-empty">
                <svg width="60" height="60" fill="none" stroke="#d1d5db" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
                <h3 className="sd-empty-title">No Certificates Yet</h3>
                <p className="sd-empty-sub">Upload your first certificate to start building your portfolio!</p>
                <button onClick={() => setShowUploadForm(true)} className="sd-upload-btn">Upload Your First Certificate</button>
              </div>
            ) : (
              <div>
                <h2 className="sd-cert-heading">Your Certificates ({certificates.length})</h2>
                <div className="certificates-grid">
                  {certificates.map(cert => (
                    <CertificateCard key={cert._id} certificate={cert} showStudent={false} userRole="student"
                      onDownload={handleDownload} onDelete={handleDelete} />
                  ))}
                </div>
              </div>
            )}
          </>
        )}

        {/* ── FEEDBACK INBOX TAB ── */}
        {activeTab === 'feedback' && (
          <div className="fb-inbox-root">
            <div className="fb-inbox-header">
              <div className="fb-inbox-title-row">
                <svg width="20" height="20" fill="none" stroke="#6366f1" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
                </svg>
                <h2 className="fb-inbox-title">Feedback from Teachers</h2>
                {feedbackUnread > 0 && <span className="fb-inbox-unread-badge">{feedbackUnread} unread</span>}
              </div>
              {feedbackUnread > 0 && (
                <button onClick={handleMarkAllFeedbackRead} className="fb-mark-all-btn">Mark all as read</button>
              )}
            </div>

            {loadingFeedback ? (
              <div className="fb-loading"><div className="fb-spinner" /><p>Loading feedback...</p></div>
            ) : feedbacks.length === 0 ? (
              <div className="fb-empty">
                <svg width="52" height="52" fill="none" stroke="#d1d5db" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
                </svg>
                <p>No feedback yet</p>
                <span>Your teachers' feedback will appear here</span>
              </div>
            ) : (
              <div className="fb-inbox-list">
                {feedbacks.map(fb => (
                  <div
                    key={fb._id}
                    className={`fb-inbox-item ${!fb.isRead ? 'fb-inbox-item-unread' : ''}`}
                    onClick={() => !fb.isRead && handleMarkFeedbackRead(fb._id)}
                  >
                    {!fb.isRead && <span className="fb-inbox-dot" />}
                    <div className="fb-inbox-avatar">{fb.teacher?.name?.[0]?.toUpperCase() || 'T'}</div>
                    <div className="fb-inbox-body">
                      <div className="fb-inbox-meta">
                        <span className="fb-inbox-teacher">{fb.teacher?.name || 'Teacher'}</span>
                        {fb.teacher?.department && <span className="fb-inbox-dept">{fb.teacher.department}</span>}
                        <span className={`fb-type-pill ${typeColors[fb.type] || 'fb-type-general'}`}>{typeLabels[fb.type] || fb.type}</span>
                        <span className="fb-inbox-date">{formatDate(fb.createdAt)}</span>
                      </div>
                      {fb.certificate && (
                        <div className="fb-inbox-cert-ref">
                          <svg width="12" height="12" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                          </svg>
                          Re: {fb.certificate.title}
                        </div>
                      )}
                      <p className="fb-inbox-msg">{fb.message}</p>
                      {!fb.isRead && <span className="fb-inbox-new-badge">NEW</span>}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default StudentDashboard;
