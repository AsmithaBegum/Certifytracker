import React, { useState, useEffect, useCallback } from 'react';
import { adminAPI, certificateAPI, feedbackAPI } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { getErrorMessage, debounce } from '../utils/helpers';
import StudentCard from '../components/StudentCard';
import CertificateCard from '../components/CertificateCard';
import socketService from '../services/socket';

const MONTHS = [
  { value: 'all', label: 'All Months' },
  { value: '1', label: 'January' }, { value: '2', label: 'February' },
  { value: '3', label: 'March' }, { value: '4', label: 'April' },
  { value: '5', label: 'May' }, { value: '6', label: 'June' },
  { value: '7', label: 'July' }, { value: '8', label: 'August' },
  { value: '9', label: 'September' }, { value: '10', label: 'October' },
  { value: '11', label: 'November' }, { value: '12', label: 'December' }
];
const YEARS = ['all', '2025', '2024', '2023', '2022', '2021', '2020'];

const TeacherDashboard = () => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('students'); // students | feedback
  const [students, setStudents] = useState([]);
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [certificates, setCertificates] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [yearFilter, setYearFilter] = useState('all');
  const [monthFilter, setMonthFilter] = useState('all');
  const [verificationFilter, setVerificationFilter] = useState('all');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [teacherDepartment, setTeacherDepartment] = useState('');
  const [stats, setStats] = useState({ total: 0, verified: 0, unverified: 0 });

  // Feedback state
  const [feedbackStudentId, setFeedbackStudentId] = useState('');
  const [feedbackCertId, setFeedbackCertId] = useState('');
  const [feedbackMessage, setFeedbackMessage] = useState('');
  const [feedbackType, setFeedbackType] = useState('general');
  const [feedbackSending, setFeedbackSending] = useState(false);
  const [feedbackSuccess, setFeedbackSuccess] = useState('');
  const [feedbackError, setFeedbackError] = useState('');
  const [sentFeedbacks, setSentFeedbacks] = useState([]);
  const [loadingFeedback, setLoadingFeedback] = useState(false);
  const [studentCerts, setStudentCerts] = useState([]);

  useEffect(() => { fetchStudents(); }, []);

  useEffect(() => {
    if (selectedStudent) fetchStudentCertificates(selectedStudent._id);
    else if (!searchQuery) fetchAllCertificates();
  }, [selectedStudent, yearFilter, monthFilter, verificationFilter]);

  useEffect(() => {
    if (activeTab === 'feedback') fetchSentFeedback();

    // Real-time: when a student reads feedback, update "Seen ✓" in the list
    const handleFeedbackSeen = ({ feedbackId }) => {
      setSentFeedbacks(prev => prev.map(f => f._id === feedbackId ? { ...f, isRead: true } : f));
    };
    const handleFeedbackSeenAll = ({ feedbackIds }) => {
      setSentFeedbacks(prev => prev.map(f => feedbackIds.includes(f._id) ? { ...f, isRead: true } : f));
    };

    socketService.on('feedback:seen', handleFeedbackSeen);
    socketService.on('feedback:seen-all', handleFeedbackSeenAll);
    return () => {
      socketService.off('feedback:seen', handleFeedbackSeen);
      socketService.off('feedback:seen-all', handleFeedbackSeenAll);
    };
  }, [activeTab]);

  // When feedback student changes, load their certs for optional cert-specific feedback
  useEffect(() => {
    if (feedbackStudentId) {
      certificateAPI.getAllCertificates({ studentId: feedbackStudentId })
        .then(r => setStudentCerts(r.data.certificates || []))
        .catch(() => setStudentCerts([]));
    } else {
      setStudentCerts([]);
    }
  }, [feedbackStudentId]);

  const fetchStudents = async () => {
    setLoading(true);
    setError('');
    try {
      const res = await adminAPI.getStudents();
      setStudents(res.data.students || []);
      if (res.data.teacherDepartment) setTeacherDepartment(res.data.teacherDepartment);
    } catch (err) { setError(getErrorMessage(err)); }
    finally { setLoading(false); }
  };

  const fetchAllCertificates = async () => {
    setLoading(true);
    setError('');
    try {
      const params = {};
      if (yearFilter !== 'all') params.year = yearFilter;
      if (monthFilter !== 'all') params.month = monthFilter;
      if (verificationFilter !== 'all') params.verificationStatus = verificationFilter;
      const res = await certificateAPI.getAllCertificates(params);
      const certs = res.data.certificates || [];
      setCertificates(certs);
      updateStats(certs);
    } catch (err) { setError(getErrorMessage(err)); }
    finally { setLoading(false); }
  };

  const fetchStudentCertificates = async (studentId) => {
    setLoading(true);
    setError('');
    try {
      const params = { studentId };
      if (yearFilter !== 'all') params.year = yearFilter;
      if (monthFilter !== 'all') params.month = monthFilter;
      if (verificationFilter !== 'all') params.verificationStatus = verificationFilter;
      const res = await certificateAPI.getAllCertificates(params);
      const certs = res.data.certificates || [];
      setCertificates(certs);
      updateStats(certs);
    } catch (err) { setError(getErrorMessage(err)); }
    finally { setLoading(false); }
  };

  const updateStats = (certs) => {
    setStats({
      total: certs.length,
      verified: certs.filter(c => c.verificationStatus === 'verified').length,
      unverified: certs.filter(c => c.verificationStatus !== 'verified').length,
    });
  };

  const debouncedSearch = useCallback(
    debounce(async (query) => {
      if (!query.trim()) { fetchAllCertificates(); return; }
      setLoading(true);
      try {
        const params = { query };
        if (yearFilter !== 'all') params.year = yearFilter;
        if (verificationFilter !== 'all') params.verificationStatus = verificationFilter;
        const res = await certificateAPI.search(params);
        const certs = res.data.certificates || [];
        setCertificates(certs);
        updateStats(certs);
      } catch (err) { setError(getErrorMessage(err)); }
      finally { setLoading(false); }
    }, 500),
    [yearFilter, verificationFilter]
  );

  useEffect(() => { if (searchQuery) debouncedSearch(searchQuery); }, [searchQuery]);

  const handleStudentClick = (student) => { setSelectedStudent(student); setSearchQuery(''); };
  const handleBackToStudents = () => { setSelectedStudent(null); setCertificates([]); };

  const handleDownloadCertificate = async (certId) => {
    try {
      const res = await certificateAPI.download(certId);
      const blob = new Blob([res.data]);
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = `certificate-${certId}.pdf`; a.click();
      window.URL.revokeObjectURL(url);
    } catch (err) { alert(getErrorMessage(err)); }
  };

  const handleViewCertificate = (certId) => certificateAPI.view(certId);

  const handleVerifyCertificate = async (certId) => {
    try {
      await certificateAPI.verify(certId);
      setCertificates(certs => certs.map(c =>
        c._id === certId ? { ...c, verificationStatus: 'verified', verificationMethod: 'manual', verifiedAt: new Date() } : c
      ));
      alert('Certificate verified!');
    } catch (err) { alert(getErrorMessage(err)); }
  };

  const handleClearSearch = () => { setSearchQuery(''); setSelectedStudent(null); fetchAllCertificates(); };

  // ── Feedback Handlers ──
  const fetchSentFeedback = async () => {
    setLoadingFeedback(true);
    try {
      const res = await feedbackAPI.getSent();
      setSentFeedbacks(res.data.feedbacks || []);
    } catch (e) { console.error(e); }
    finally { setLoadingFeedback(false); }
  };

  const handleSendFeedback = async (e) => {
    e.preventDefault();
    setFeedbackError(''); setFeedbackSuccess('');
    if (!feedbackStudentId || !feedbackMessage.trim()) {
      setFeedbackError('Please select a student and write a message.');
      return;
    }
    setFeedbackSending(true);
    try {
      await feedbackAPI.send({
        studentId: feedbackStudentId,
        message: feedbackMessage,
        certificateId: feedbackCertId || undefined,
        type: feedbackType
      });
      setFeedbackSuccess('Feedback sent successfully!');
      setFeedbackMessage(''); setFeedbackCertId(''); setFeedbackType('general');
      fetchSentFeedback();
      setTimeout(() => setFeedbackSuccess(''), 4000);
    } catch (err) {
      setFeedbackError(getErrorMessage(err));
    } finally { setFeedbackSending(false); }
  };

  const handleDeleteFeedback = async (id) => {
    if (!window.confirm('Delete this feedback?')) return;
    try {
      await feedbackAPI.delete(id);
      setSentFeedbacks(prev => prev.filter(f => f._id !== id));
    } catch (e) { alert(getErrorMessage(e)); }
  };

  const typeLabels = { general: '💬 General', certificate: '📄 Certificate', encouragement: '🌟 Encouragement', improvement: '🔧 Improvement' };
  const typeColors = { general: 'fb-type-general', certificate: 'fb-type-certificate', encouragement: 'fb-type-encourage', improvement: 'fb-type-improve' };

  const formatDate = (d) => new Date(d).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });

  return (
    <div className="td-root">
      {/* Header */}
      <div className="td-header">
        <div className="td-header-inner">
          <div>
            <h1 className="td-title">
              <svg width="28" height="28" fill="none" stroke="white" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                  d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
              Teacher Dashboard
            </h1>
            <p className="td-subtitle">
              {teacherDepartment
                ? <span>Dept: <strong>{teacherDepartment}</strong>{selectedStudent ? ` › ${selectedStudent.name}` : ' › All Students'}</span>
                : selectedStudent ? `Viewing ${selectedStudent.name}` : 'Manage your students'}
            </p>
          </div>
          {teacherDepartment && <span className="td-dept-badge">{teacherDepartment}</span>}
        </div>

        {/* Tab bar */}
        <div className="td-tabs">
          <button className={`td-tab ${activeTab === 'students' ? 'td-tab-active' : ''}`} onClick={() => setActiveTab('students')}>
            <svg width="15" height="15" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
            </svg>
            Students & Certificates
          </button>
          <button className={`td-tab ${activeTab === 'feedback' ? 'td-tab-active' : ''}`} onClick={() => setActiveTab('feedback')}>
            <svg width="15" height="15" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
            </svg>
            Feedback
            {sentFeedbacks.length > 0 && <span className="td-tab-badge">{sentFeedbacks.length}</span>}
          </button>
        </div>
      </div>

      <div className="td-container">
        {/* ── STUDENTS TAB ── */}
        {activeTab === 'students' && (
          <>
            {error && <div className="td-error">{error}</div>}

            {(selectedStudent || searchQuery) && (
              <div className="td-stats-bar">
                {[['Total', stats.total, '#6366f1'], ['Verified', stats.verified, '#10b981'], ['Pending', stats.unverified, '#f59e0b']].map(([l, v, c]) => (
                  <React.Fragment key={l}>
                    <div className="td-stat-item">
                      <span className="td-stat-num" style={{ color: c }}>{v}</span>
                      <span className="td-stat-label">{l}</span>
                    </div>
                    {l !== 'Pending' && <div className="td-stat-div" />}
                  </React.Fragment>
                ))}
              </div>
            )}

            {/* Filters */}
            <div className="td-filters">
              <div className="td-filters-grid">
                <div className="td-filter-search">
                  <label className="td-filter-label">Search (NLP)</label>
                  <div className="td-search-wrap">
                    <input type="text" placeholder="e.g., Python, React, Machine Learning..."
                      value={searchQuery} onChange={e => setSearchQuery(e.target.value)} className="td-search-input" />
                    {searchQuery && (
                      <button onClick={handleClearSearch} className="td-search-clear">
                        <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                        </svg>
                      </button>
                    )}
                  </div>
                </div>
                <div className="td-filter-field">
                  <label className="td-filter-label">Year</label>
                  <select value={yearFilter} onChange={e => setYearFilter(e.target.value)} className="td-filter-select">
                    {YEARS.map(y => <option key={y} value={y}>{y === 'all' ? 'All Years' : y}</option>)}
                  </select>
                </div>
                <div className="td-filter-field">
                  <label className="td-filter-label">Month</label>
                  <select value={monthFilter} onChange={e => setMonthFilter(e.target.value)} className="td-filter-select">
                    {MONTHS.map(m => <option key={m.value} value={m.value}>{m.label}</option>)}
                  </select>
                </div>
                <div className="td-filter-field">
                  <label className="td-filter-label">Status</label>
                  <select value={verificationFilter} onChange={e => setVerificationFilter(e.target.value)} className="td-filter-select">
                    <option value="all">All Status</option>
                    <option value="verified">✓ Verified</option>
                    <option value="unverified">○ Unverified</option>
                  </select>
                </div>
              </div>
              {(yearFilter !== 'all' || monthFilter !== 'all' || verificationFilter !== 'all') && (
                <div className="td-active-filters">
                  <span className="td-filter-hint">Active:</span>
                  {yearFilter !== 'all' && <span className="td-filter-tag">{yearFilter} <button onClick={() => setYearFilter('all')}>×</button></span>}
                  {monthFilter !== 'all' && <span className="td-filter-tag">{MONTHS.find(m => m.value === monthFilter)?.label} <button onClick={() => setMonthFilter('all')}>×</button></span>}
                  {verificationFilter !== 'all' && <span className="td-filter-tag">{verificationFilter} <button onClick={() => setVerificationFilter('all')}>×</button></span>}
                  <button className="td-filter-clear-all" onClick={() => { setYearFilter('all'); setMonthFilter('all'); setVerificationFilter('all'); }}>Clear all</button>
                </div>
              )}
            </div>

            {selectedStudent && (
              <button onClick={handleBackToStudents} className="td-back-btn">
                <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                </svg>
                Back to Students
              </button>
            )}

            {loading ? (
              <div className="td-loading"><div className="td-spinner" /><p>Loading...</p></div>
            ) : (
              <>
                {/* Students Grid */}
                {!selectedStudent && !searchQuery && (
                  <div>
                    <div className="td-section-header">
                      <h2 className="td-section-title">{teacherDepartment ? `${teacherDepartment} Students` : 'All Students'}</h2>
                      <span className="td-section-count">{students.length} students</span>
                    </div>
                    {students.length === 0 ? (
                      <div className="td-empty">
                        <svg width="52" height="52" fill="none" stroke="#d1d5db" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
                        </svg>
                        <p className="td-empty-title">No Students Found</p>
                        <p className="td-empty-desc">{teacherDepartment ? `No approved students in ${teacherDepartment} yet.` : 'No approved students registered yet.'}</p>
                      </div>
                    ) : (
                      <div className="students-grid">
                        {students.map((s, i) => <StudentCard key={s._id} student={s} index={i + 1} onClick={handleStudentClick} />)}
                      </div>
                    )}
                  </div>
                )}

                {/* Certificates Grid */}
                {(selectedStudent || searchQuery) && (
                  <div>
                    <div className="td-section-header">
                      <div>
                        <h2 className="td-section-title">{certificates.length} Certificate{certificates.length !== 1 ? 's' : ''} Found</h2>
                        {selectedStudent && (
                          <p className="td-section-sub">
                            <strong>{selectedStudent.name}</strong>
                            {selectedStudent.rollNumber && <span className="td-roll"> · #{selectedStudent.rollNumber}</span>}
                            {selectedStudent.department && <span className="td-dept-pill">{selectedStudent.department}</span>}
                          </p>
                        )}
                      </div>
                      {selectedStudent && (
                        <button
                          className="td-feedback-shortcut"
                          onClick={() => { setFeedbackStudentId(selectedStudent._id); setActiveTab('feedback'); }}
                        >
                          <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
                          </svg>
                          Give Feedback
                        </button>
                      )}
                    </div>

                    {certificates.length === 0 ? (
                      <div className="td-empty">
                        <svg width="52" height="52" fill="none" stroke="#d1d5db" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                        </svg>
                        <p className="td-empty-title">No Certificates Found</p>
                        <p className="td-empty-desc">{searchQuery ? 'No certificates match your search.' : 'This student has not uploaded certificates yet.'}</p>
                      </div>
                    ) : (
                      <div className="certificates-grid">
                        {certificates.map(cert => (
                          <CertificateCard key={cert._id} certificate={cert} showStudent={!selectedStudent} userRole="teacher"
                            onView={handleViewCertificate} onDownload={handleDownloadCertificate} onVerify={handleVerifyCertificate} />
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </>
            )}
          </>
        )}

        {/* ── FEEDBACK TAB ── */}
        {activeTab === 'feedback' && (
          <div className="fb-root">
            {/* Send Feedback Form */}
            <div className="fb-form-card">
              <div className="fb-form-header">
                <svg width="20" height="20" fill="none" stroke="#6366f1" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
                </svg>
                <h2 className="fb-form-title">Send Feedback to Student</h2>
              </div>

              {feedbackSuccess && <div className="fb-success">{feedbackSuccess}</div>}
              {feedbackError && <div className="fb-error">{feedbackError}</div>}

              <form onSubmit={handleSendFeedback} className="fb-form">
                <div className="fb-form-row">
                  <div className="fb-field">
                    <label className="fb-label">Select Student <span>*</span></label>
                    <select value={feedbackStudentId} onChange={e => setFeedbackStudentId(e.target.value)} className="fb-select" required>
                      <option value="">Choose a student...</option>
                      {students.map(s => (
                        <option key={s._id} value={s._id}>{s.name}{s.rollNumber ? ` (${s.rollNumber})` : ''}</option>
                      ))}
                    </select>
                  </div>
                  <div className="fb-field">
                    <label className="fb-label">Feedback Type</label>
                    <select value={feedbackType} onChange={e => setFeedbackType(e.target.value)} className="fb-select">
                      <option value="general">💬 General</option>
                      <option value="certificate">📄 Certificate Specific</option>
                      <option value="encouragement">🌟 Encouragement</option>
                      <option value="improvement">🔧 Needs Improvement</option>
                    </select>
                  </div>
                </div>

                {feedbackStudentId && studentCerts.length > 0 && (
                  <div className="fb-field">
                    <label className="fb-label">Related Certificate (optional)</label>
                    <select value={feedbackCertId} onChange={e => setFeedbackCertId(e.target.value)} className="fb-select">
                      <option value="">None – General feedback</option>
                      {studentCerts.map(c => (
                        <option key={c._id} value={c._id}>{c.title} ({c.category})</option>
                      ))}
                    </select>
                  </div>
                )}

                <div className="fb-field">
                  <label className="fb-label">Your Feedback <span>*</span></label>
                  <textarea
                    value={feedbackMessage}
                    onChange={e => setFeedbackMessage(e.target.value)}
                    placeholder="Write your feedback here... Be specific and constructive."
                    rows={4} className="fb-textarea" required maxLength={1000}
                  />
                  <span className="fb-char-count">{feedbackMessage.length}/1000</span>
                </div>

                <div className="fb-form-footer">
                  <button type="button" className="fb-cancel-btn" onClick={() => { setFeedbackMessage(''); setFeedbackStudentId(''); setFeedbackCertId(''); }}>
                    Clear
                  </button>
                  <button type="submit" disabled={feedbackSending} className="fb-send-btn">
                    {feedbackSending ? (
                      <><div className="fb-btn-spinner" /> Sending...</>
                    ) : (
                      <><svg width="15" height="15" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                      </svg> Send Feedback</>
                    )}
                  </button>
                </div>
              </form>
            </div>

            {/* Sent Feedback History */}
            <div className="fb-history-card">
              <div className="fb-history-header">
                <h2 className="fb-history-title">Sent Feedback History</h2>
                <span className="fb-history-count">{sentFeedbacks.length} sent</span>
              </div>

              {loadingFeedback ? (
                <div className="fb-loading"><div className="fb-spinner" /><p>Loading...</p></div>
              ) : sentFeedbacks.length === 0 ? (
                <div className="fb-empty">
                  <svg width="44" height="44" fill="none" stroke="#d1d5db" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
                  </svg>
                  <p>No feedback sent yet.</p>
                  <span>Use the form above to send your first feedback.</span>
                </div>
              ) : (
                <div className="fb-list">
                  {sentFeedbacks.map(fb => (
                    <div key={fb._id} className="fb-item">
                      <div className="fb-item-header">
                        <div className="fb-item-student">
                          <div className="fb-student-avatar">{fb.student?.name?.[0]?.toUpperCase() || '?'}</div>
                          <div>
                            <p className="fb-student-name">{fb.student?.name || 'Unknown'}</p>
                            {fb.student?.rollNumber && <p className="fb-student-roll">Roll #{fb.student.rollNumber}</p>}
                          </div>
                        </div>
                        <div className="fb-item-meta">
                          <span className={`fb-type-pill ${typeColors[fb.type] || 'fb-type-general'}`}>{typeLabels[fb.type] || fb.type}</span>
                          <span className="fb-date">{formatDate(fb.createdAt)}</span>
                        </div>
                      </div>
                      {fb.certificate && (
                        <div className="fb-cert-ref">
                          <svg width="12" height="12" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                          </svg>
                          {fb.certificate.title}
                        </div>
                      )}
                      <p className="fb-item-msg">{fb.message}</p>
                      <div className="fb-item-footer">
                        <span className={`fb-read-pill ${fb.isRead ? 'fb-read' : 'fb-unread'}`}>{fb.isRead ? '✓ Read' : '● Unread'}</span>
                        <button onClick={() => handleDeleteFeedback(fb._id)} className="fb-delete-btn" title="Delete">
                          <svg width="13" height="13" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                          </svg>
                          Delete
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default TeacherDashboard;
