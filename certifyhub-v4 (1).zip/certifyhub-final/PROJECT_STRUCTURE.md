# CertifyHub - Complete Project Structure

## Directory Layout

```
certifyhub/
├── backend/
│   ├── config/
│   │   └── db.js                    # MongoDB connection
│   ├── controllers/
│   │   ├── authController.js        # Authentication logic
│   │   ├── certificateController.js # Certificate CRUD & search
│   │   ├── adminController.js       # Admin operations
│   │   ├── mlController.js          # ML analysis endpoints
│   │   └── notificationController.js# Real-time notifications
│   ├── middleware/
│   │   ├── auth.js                  # JWT & role-based auth
│   │   └── upload.js                # Multer file upload
│   ├── models/
│   │   ├── User.js                  # User schema with notifications
│   │   └── Certificate.js           # Certificate schema
│   ├── routes/
│   │   ├── auth.js                  # Auth routes
│   │   ├── certificates.js          # Certificate routes
│   │   ├── admin.js                 # Admin routes
│   │   ├── ml.js                    # ML routes
│   │   └── notifications.js         # Notification routes
│   ├── utils/
│   │   ├── nlpService.js            # NLP search & categorization
│   │   ├── mlService.js             # Random Forest ML analysis
│   │   └── verificationService.js   # Certificate verification
│   ├── uploads/
│   │   └── certificates/            # Uploaded certificate files
│   ├── scripts/
│   │   └── createAdmin.js           # CLI script to create admin
│   ├── server.js                    # Express server & Socket.io
│   ├── package.json
│   └── .env

└── frontend/
    ├── public/
    ├── src/
    │   ├── components/
    │   │   ├── Admin/
    │   │   │   ├── Dashboard.jsx
    │   │   │   ├── PendingApprovals.jsx
    │   │   │   ├── ManageUsers.jsx
    │   │   │   └── AllCertificates.jsx
    │   │   ├── Teacher/
    │   │   │   ├── Dashboard.jsx
    │   │   │   ├── StudentList.jsx
    │   │   │   ├── CertificateView.jsx
    │   │   │   └── NotificationBell.jsx
    │   │   ├── Student/
    │   │   │   ├── Dashboard.jsx
    │   │   │   ├── UploadCertificate.jsx
    │   │   │   ├── MyCertificates.jsx
    │   │   │   └── GrowthAnalysis.jsx
    │   │   ├── Auth/
    │   │   │   ├── Login.jsx
    │   │   │   └── Register.jsx
    │   │   └── Common/
    │   │       ├── Navbar.jsx
    │   │       ├── PrivateRoute.jsx
    │   │       └── CertificateCard.jsx
    │   ├── context/
    │   │   ├── AuthContext.jsx
    │   │   └── SocketContext.jsx
    │   ├── utils/
    │   │   ├── api.js
    │   │   └── socket.js
    │   ├── App.jsx
    │   ├── index.jsx
    │   └── index.css
    ├── package.json
    └── tailwind.config.js
```

## Key Features by File

### Backend Controllers:
- **authController.js**: Registration, login, JWT generation
- **certificateController.js**: Upload, view, download, delete, NLP search
- **adminController.js**: Approve/reject users, manage users, view all certificates
- **mlController.js**: Random Forest analysis, growth charts, recommendations
- **notificationController.js**: Socket.io real-time notifications

### Frontend Components:
- **Admin Dashboard**: Statistics, pending approvals, user management, all certificates
- **Teacher Dashboard**: View students, NLP search, year filtering, notifications
- **Student Dashboard**: Upload certificates, view own certificates, ML growth analysis

### Utilities:
- **nlpService.js**: Natural.js + Compromise.js for keyword extraction and search
- **mlService.js**: 5 decision trees for career readiness scoring
- **verificationService.js**: Certificate verification with external APIs

## Installation Steps

### Backend:
```bash
cd backend
npm install
# Create .env file with MongoDB URI and JWT secret
npm run create-admin  # Create admin account
npm run dev           # Start development server
```

### Frontend:
```bash
cd frontend
npm install
npm start             # Start React app
```

## Default Ports
- Backend: http://localhost:5000
- Frontend: http://localhost:3000
- MongoDB: mongodb://localhost:27017/certifyhub

## First Time Setup
1. Start MongoDB
2. Start backend server
3. Run create-admin script to create admin account
4. Start frontend
5. Login as admin and approve student/teacher registrations
