const mongoose = require('mongoose');

const feedbackSchema = new mongoose.Schema({
  teacher: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  student: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  certificate: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Certificate',
    default: null  // null = general feedback (not cert-specific)
  },
  message: {
    type: String,
    required: true,
    trim: true,
    maxlength: 1000
  },
  type: {
    type: String,
    enum: ['general', 'certificate', 'encouragement', 'improvement'],
    default: 'general'
  },
  isRead: {
    type: Boolean,
    default: false
  }
}, { timestamps: true });

feedbackSchema.index({ student: 1, createdAt: -1 });
feedbackSchema.index({ teacher: 1, createdAt: -1 });

module.exports = mongoose.model('Feedback', feedbackSchema);
