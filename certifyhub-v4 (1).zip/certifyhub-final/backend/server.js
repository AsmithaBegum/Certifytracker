const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const http = require('http');
const socketIO = require('socket.io');
const path = require('path');
require('dotenv').config();

const app = express();
const server = http.createServer(app);
const io = socketIO(server, {
  cors: {
    origin: process.env.CLIENT_URL || 'http://localhost:3000',
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    credentials: true
  }
});

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

mongoose.connect(process.env.MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => console.log('✅ MongoDB connected'))
.catch(err => console.error('❌ MongoDB error:', err));

const User = require('./models/User');
const Certificate = require('./models/Certificate');

const connectedUsers = new Map();

io.on('connection', (socket) => {
  console.log('🔌 Client connected:', socket.id);

  socket.on('user:join', (userId) => {
    connectedUsers.set(userId, socket.id);
    socket.userId = userId;
    console.log(`👤 User ${userId} joined`);
  });

  socket.on('disconnect', () => {
    if (socket.userId) connectedUsers.delete(socket.userId);
  });

  socket.on('notification:read', async ({ userId, notificationId }) => {
    try {
      const user = await User.findById(userId);
      if (user) {
        const notif = user.notifications.id(notificationId);
        if (notif) { notif.isRead = true; await user.save(); }
        socket.emit('notification:updated', { notificationId, isRead: true });
      }
    } catch (e) { console.error(e); }
  });

  socket.on('notification:read-all', async ({ userId }) => {
    try {
      const user = await User.findById(userId);
      if (user) {
        user.notifications.forEach(n => { n.isRead = true; });
        await user.save();
        socket.emit('notification:all-read');
      }
    } catch (e) { console.error(e); }
  });

  socket.on('notification:delete', async ({ userId, notificationId }) => {
    try {
      const user = await User.findById(userId);
      if (user) {
        user.notifications = user.notifications.filter(n => n._id.toString() !== notificationId);
        await user.save();
        socket.emit('notification:deleted', { notificationId });
      }
    } catch (e) { console.error(e); }
  });
});

app.set('io', io);
app.set('connectedUsers', connectedUsers);

// ── STRICT Department-Only Teacher Notifications ─────────────────────────────
// IT teacher → gets ONLY IT student uploads
// CSE teacher → gets ONLY CSE student uploads
// Teacher with no department set → gets ALL notifications
async function sendNotificationToTeachers(certificate) {
  try {
    // Ensure student is fully populated
    if (!certificate.student || !certificate.student.name) {
      await certificate.populate('student', 'name rollNumber department');
    }

    const studentDept = (certificate.student.department || '').trim();
    const studentName = certificate.student.name;

    console.log(`📢 Certificate upload by ${studentName} (dept: "${studentDept}") — finding matching teachers...`);

    // Get ALL approved teachers
    const allTeachers = await User.find({ role: 'teacher', isApproved: true });

    // Filter: teacher receives notification ONLY if:
    //   - teacher has no department set (receives all), OR
    //   - teacher's department matches student's department (case-insensitive)
    const targetTeachers = allTeachers.filter(teacher => {
      const teacherDept = (teacher.department || '').trim();
      if (!teacherDept) return true;                                      // no dept → receives all
      if (!studentDept) return true;                                      // student has no dept → notify everyone
      return teacherDept.toLowerCase() === studentDept.toLowerCase();     // strict match
    });

    if (targetTeachers.length === 0) {
      console.log(`⚠️  No teachers found for dept "${studentDept}"`);
      return;
    }

    const notification = {
      message: `📄 ${studentName} uploaded "${certificate.title}"`,
      certificateId: certificate._id,
      studentName,
      studentDept,
      isRead: false,
      createdAt: new Date()
    };

    for (const teacher of targetTeachers) {
      if (teacher.notifications.length >= 50) {
        teacher.notifications = teacher.notifications.slice(-49);
      }
      teacher.notifications.push(notification);
      await teacher.save();

      const socketId = connectedUsers.get(teacher._id.toString());
      if (socketId) {
        const saved = teacher.notifications[teacher.notifications.length - 1];
        io.to(socketId).emit('notification:new', {
          notification: saved,
          unreadCount: teacher.notifications.filter(n => !n.isRead).length
        });
      }
    }

    console.log(`✉️  Notified ${targetTeachers.length} teacher(s) — dept match: "${studentDept}"`);
    targetTeachers.forEach(t => console.log(`   → ${t.name} (dept: ${t.department || 'any'})`));
  } catch (error) {
    console.error('❌ Error in sendNotificationToTeachers:', error);
  }
}

app.set('sendNotificationToTeachers', sendNotificationToTeachers);

// Routes
app.use('/api/auth', require('./routes/auth'));
app.use('/api/certificates', require('./routes/certificates'));
app.use('/api/admin', require('./routes/admin'));
app.use('/api/ml', require('./routes/ml'));
app.use('/api/feedback', require('./routes/feedback'));

// Inline Notification REST routes
const notificationRouter = express.Router();
const { auth } = require('./middleware/auth');

notificationRouter.get('/', auth, async (req, res) => {
  try {
    const user = await User.findById(req.userId).select('notifications');
    const sorted = (user.notifications || []).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    res.json({ notifications: sorted, unreadCount: sorted.filter(n => !n.isRead).length });
  } catch (e) { res.status(500).json({ error: 'Server error' }); }
});

notificationRouter.put('/read-all', auth, async (req, res) => {
  try {
    await User.updateOne({ _id: req.userId }, { $set: { 'notifications.$[].isRead': true } });
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: 'Server error' }); }
});

notificationRouter.put('/:id/read', auth, async (req, res) => {
  try {
    const user = await User.findById(req.userId);
    const notif = user.notifications.id(req.params.id);
    if (notif) { notif.isRead = true; await user.save(); }
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: 'Server error' }); }
});

notificationRouter.delete('/clear-all', auth, async (req, res) => {
  try {
    await User.updateOne({ _id: req.userId }, { $set: { notifications: [] } });
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: 'Server error' }); }
});

notificationRouter.delete('/:id', auth, async (req, res) => {
  try {
    await User.updateOne({ _id: req.userId }, { $pull: { notifications: { _id: req.params.id } } });
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: 'Server error' }); }
});

app.use('/api/notifications', notificationRouter);

app.get('/health', (req, res) => res.json({ status: 'OK', timestamp: new Date() }));
app.use((req, res) => res.status(404).json({ error: 'Route not found' }));
app.use((err, req, res, next) => res.status(500).json({ error: 'Internal server error' }));

const PORT = process.env.PORT || 5000;
server.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));

module.exports = { app, io };
