const jwt = require('jsonwebtoken');
const User = require('../models/User');

// Auth middleware — accepts token from Authorization header OR ?token= query param
// The query param is needed for window.open() and iframe src (can't send headers)
const auth = async (req, res, next) => {
  try {
    const token = req.header('Authorization')?.replace('Bearer ', '') || req.query.token;
    if (!token) return res.status(401).json({ error: 'No authentication token provided' });

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.userId);
    if (!user) return res.status(401).json({ error: 'User not found' });

    if (user.role !== 'admin' && !user.isApproved) {
      return res.status(403).json({ error: 'Your account is pending approval' });
    }

    req.user = user;
    req.userId = user._id;
    req.userRole = user.role;
    next();
  } catch (error) {
    res.status(401).json({ error: 'Invalid or expired token' });
  }
};

const protect = auth; // alias used in some routes

const authorize = (...roles) => (req, res, next) => {
  if (!req.user) return res.status(401).json({ error: 'Unauthorized' });
  if (!roles.includes(req.userRole)) return res.status(403).json({ error: `Access denied. Required: ${roles.join(', ')}` });
  next();
};

const adminOnly      = authorize('admin');
const teacherOrAdmin = authorize('teacher', 'admin');
const studentOnly    = authorize('student');

module.exports = { auth, protect, authorize, adminOnly, teacherOrAdmin, studentOnly };
