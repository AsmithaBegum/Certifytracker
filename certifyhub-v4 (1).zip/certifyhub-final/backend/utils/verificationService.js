const axios = require('axios');

// Simulated external API verification (90% success rate for demo)
const simulateVerification = async (issuer, certificateId, qrCodeData) => {
  // Simulate API call delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  // 90% success rate
  const isValid = Math.random() < 0.9;
  
  return {
    verified: isValid,
    issuer,
    certificateId,
    verificationDate: new Date(),
    message: isValid 
      ? `Certificate verified with ${issuer}` 
      : `Unable to verify certificate with ${issuer}`
  };
};

// Verify certificate using Certificate ID
exports.verifyCertificateId = async (issuer, certificateId) => {
  try {
    // In production, this would make actual API calls to:
    // - Coursera: https://api.coursera.org/api/certificates.v1/
    // - Udemy: https://www.udemy.com/api-2.0/certificates/
    // - LinkedIn: LinkedIn API
    // - Google, Microsoft, AWS: respective APIs
    
    const result = await simulateVerification(issuer, certificateId, null);
    
    return {
      isVerified: result.verified,
      method: 'Certificate ID',
      verificationDate: result.verificationDate,
      details: result
    };
  } catch (error) {
    return {
      isVerified: false,
      method: 'Certificate ID',
      error: error.message
    };
  }
};

// Verify certificate using QR Code
exports.verifyQRCode = async (issuer, qrCodeData) => {
  try {
    // In production, this would:
    // 1. Parse QR code data
    // 2. Extract verification URL or ID
    // 3. Make API call to issuer's verification endpoint
    
    const result = await simulateVerification(issuer, null, qrCodeData);
    
    return {
      isVerified: result.verified,
      method: 'QR Code',
      verificationDate: result.verificationDate,
      details: result
    };
  } catch (error) {
    return {
      isVerified: false,
      method: 'QR Code',
      error: error.message
    };
  }
};

// Automatic verification when certificate is uploaded
exports.autoVerify = async (certificateData) => {
  const { issuer, certificateId, qrCodeData } = certificateData;
  
  // Try Certificate ID first
  if (certificateId && issuer && issuer !== 'Other') {
    const result = await this.verifyCertificateId(issuer, certificateId);
    if (result.isVerified) {
      return result;
    }
  }
  
  // Try QR Code
  if (qrCodeData && issuer && issuer !== 'Other') {
    const result = await this.verifyQRCode(issuer, qrCodeData);
    if (result.isVerified) {
      return result;
    }
  }
  
  // Not verified
  return {
    isVerified: false,
    method: 'Not Verified',
    message: 'Automatic verification not available for this certificate'
  };
};

// Manual verification by teacher/admin
exports.manualVerify = async (certificateId, verifiedBy) => {
  return {
    isVerified: true,
    method: 'Manual',
    verificationDate: new Date(),
    verifiedBy
  };
};

// Get supported issuers
exports.getSupportedIssuers = () => {
  return [
    'Coursera',
    'Udemy',
    'LinkedIn',
    'Google',
    'Microsoft',
    'AWS',
    'Other'
  ];
};
