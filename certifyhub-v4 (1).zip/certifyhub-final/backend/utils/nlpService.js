const natural = require('natural');
const compromise = require('compromise');

// Initialize tokenizer and TF-IDF
const tokenizer = new natural.WordTokenizer();
const TfIdf = natural.TfIdf;

// Keyword patterns for categorization
const categoryPatterns = {
  Backend: [
    'java', 'python', 'node', 'nodejs', 'spring', 'django', 'flask', 
    'express', 'api', 'rest', 'graphql', 'microservices', 'backend',
    'server', 'php', 'ruby', 'rails', 'laravel', 'fastapi', 'nestjs'
  ],
  Frontend: [
    'react', 'angular', 'vue', 'html', 'css', 'javascript', 'js',
    'typescript', 'frontend', 'ui', 'ux', 'web design', 'sass', 'scss',
    'tailwind', 'bootstrap', 'next', 'nuxt', 'svelte', 'jquery', 'webpack'
  ],
  Database: [
    'sql', 'mysql', 'postgresql', 'postgres', 'mongodb', 'database',
    'nosql', 'redis', 'oracle', 'db', 'data modeling', 'query',
    'mariadb', 'cassandra', 'dynamodb', 'firebase', 'supabase'
  ],
  Cloud: [
    'aws', 'azure', 'cloud', 'docker', 'kubernetes', 'k8s', 'devops',
    'gcp', 'google cloud', 'serverless', 'lambda', 'ec2', 's3',
    'container', 'deployment', 'ci/cd', 'jenkins', 'terraform'
  ],
  'AI/ML': [
    'machine learning', 'ml', 'ai', 'artificial intelligence', 'deep learning',
    'neural network', 'tensorflow', 'pytorch', 'data science', 'nlp',
    'computer vision', 'opencv', 'scikit', 'pandas', 'numpy', 'keras',
    'generative', 'llm', 'chatgpt', 'model training', 'algorithm'
  ],
  Mobile: [
    'android', 'ios', 'mobile', 'flutter', 'react native', 'swift',
    'kotlin', 'app development', 'mobile app', 'xamarin', 'ionic'
  ],
  Programming: [
    'programming', 'coding', 'software', 'development', 'algorithm',
    'data structures', 'oop', 'functional', 'dsa', 'competitive',
    'leetcode', 'hackerrank', 'problem solving', 'c++', 'c', 'go', 'rust'
  ]
};

// Extract keywords from text
exports.extractKeywords = (text) => {
  const lowerText = text.toLowerCase();
  
  // Use compromise for better NLP
  const doc = compromise(text);
  
  // Extract nouns, proper nouns, and technical terms
  const nouns = doc.nouns().out('array');
  const topics = doc.topics().out('array');
  
  // Tokenize and remove stop words
  const tokens = tokenizer.tokenize(lowerText);
  const stopwords = natural.stopwords;
  
  // Filter meaningful tokens
  const filtered = tokens.filter(token => 
    token.length > 2 && 
    !stopwords.includes(token) &&
    /^[a-zA-Z0-9+#]+$/.test(token)
  );
  
  // Combine and deduplicate
  const allKeywords = [...new Set([...nouns, ...topics, ...filtered])];
  
  // Return top 10 keywords
  return allKeywords.slice(0, 10);
};

// Categorize certificate based on keywords
exports.categorize = (title, description) => {
  const text = `${title} ${description}`.toLowerCase();
  
  let maxScore = 0;
  let bestCategory = 'Other';
  
  // Score each category
  for (const [category, patterns] of Object.entries(categoryPatterns)) {
    let score = 0;
    
    for (const pattern of patterns) {
      if (text.includes(pattern.toLowerCase())) {
        score += 1;
        
        // Boost score if pattern is in title
        if (title.toLowerCase().includes(pattern.toLowerCase())) {
          score += 2;
        }
      }
    }
    
    if (score > maxScore) {
      maxScore = score;
      bestCategory = category;
    }
  }
  
  return bestCategory;
};

// Search certificates using NLP
exports.searchCertificates = (certificates, query) => {
  const lowerQuery = query.toLowerCase();
  const queryTokens = tokenizer.tokenize(lowerQuery);
  const queryDoc = compromise(query);
  const queryNouns = queryDoc.nouns().out('array').map(n => n.toLowerCase());
  
  // Score each certificate
  const scored = certificates.map(cert => {
    let score = 0;
    const certText = `${cert.title} ${cert.description}`.toLowerCase();
    
    // Exact phrase match (highest priority)
    if (certText.includes(lowerQuery)) {
      score += 10;
    }
    
    // Title match
    if (cert.title.toLowerCase().includes(lowerQuery)) {
      score += 8;
    }
    
    // Category match
    if (cert.category && cert.category.toLowerCase().includes(lowerQuery)) {
      score += 5;
    }
    
    // Keyword matches
    if (cert.keywords) {
      for (const keyword of cert.keywords) {
        if (lowerQuery.includes(keyword.toLowerCase()) || 
            keyword.toLowerCase().includes(lowerQuery)) {
          score += 3;
        }
      }
    }
    
    // Token matches
    for (const token of queryTokens) {
      if (certText.includes(token)) {
        score += 1;
      }
    }
    
    // Noun matches
    for (const noun of queryNouns) {
      if (certText.includes(noun)) {
        score += 2;
      }
    }
    
    return { certificate: cert, score };
  });
  
  // Filter and sort by score
  return scored
    .filter(item => item.score > 0)
    .sort((a, b) => b.score - a.score)
    .map(item => item.certificate);
};

// Get search suggestions
exports.getSearchSuggestions = (certificates) => {
  const suggestions = new Set();
  
  certificates.forEach(cert => {
    // Add categories
    if (cert.category && cert.category !== 'Other') {
      suggestions.add(cert.category);
    }
    
    // Add keywords
    if (cert.keywords) {
      cert.keywords.forEach(keyword => {
        if (keyword.length > 3) {
          suggestions.add(keyword);
        }
      });
    }
  });
  
  return Array.from(suggestions).slice(0, 20);
};
