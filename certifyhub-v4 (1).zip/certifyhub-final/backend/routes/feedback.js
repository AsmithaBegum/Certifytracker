const express = require('express');
const router = express.Router();
const Feedback = require('../models/Feedback');
const User = require('../models/User');
const { auth, teacherOrAdmin, studentOnly } = require('../middleware/auth');

// Teacher sends feedback to a student
router.post('/', auth, teacherOrAdmin, async (req, res) => {
  try {
    const { studentId, message, certificateId, type } = req.body;

    if (!studentId || !message) {
      return res.status(400).json({ error: 'studentId and message are required' });
    }

    const student = await User.findById(studentId);
    if (!student || student.role !== 'student') {
      return res.status(404).json({ error: 'Student not found' });
    }

    // ── Dept check: teacher can only send feedback to same-dept students ──
    const teacher = await User.findById(req.userId);
    const teacherDept = (teacher.department || '').trim().toLowerCase();
    const studentDept = (student.department || '').trim().toLowerCase();
    if (teacherDept && studentDept && teacherDept !== studentDept) {
      return res.status(403).json({ error: `You can only send feedback to students in your department (${teacher.department}).` });
    }

    const feedback = new Feedback({
      teacher: req.userId,
      student: studentId,
      certificate: certificateId || null,
      message,
      type: type || 'general'
    });

    await feedback.save();
    await feedback.populate('teacher', 'name department');
    await feedback.populate('certificate', 'title category');

    // Notify student
    const notifMessage = `💬 ${req.user.name} sent you feedback${feedback.certificate ? ` on "${feedback.certificate.title}"` : ''}: "${message.substring(0, 60)}${message.length > 60 ? '...' : ''}"`;

    await User.updateOne(
      { _id: studentId },
      {
        $push: {
          notifications: {
            $each: [{ message: notifMessage, certificateId: certificateId || null, studentName: req.user.name, isRead: false, createdAt: new Date() }],
            $slice: -50
          }
        }
      }
    );

    // Real-time to student
    const io = req.app.get('io');
    const connectedUsers = req.app.get('connectedUsers');
    if (io && connectedUsers) {
      const studentSocket = connectedUsers.get(studentId.toString());
      if (studentSocket) io.to(studentSocket).emit('feedback:new', { feedback, message: notifMessage });
    }

    res.status(201).json({ message: 'Feedback sent successfully', feedback });
  } catch (error) {
    console.error('Feedback send error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Teacher: get all feedback they sent
router.get('/sent', auth, teacherOrAdmin, async (req, res) => {
  try {
    const feedbacks = await Feedback.find({ teacher: req.userId })
      .populate('student', 'name rollNumber department')
      .populate('certificate', 'title category')
      .sort({ createdAt: -1 });
    res.json({ feedbacks });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Student: get all feedback received
router.get('/received', auth, async (req, res) => {
  try {
    if (req.userRole !== 'student') {
      return res.status(403).json({ error: 'Students only' });
    }
    const feedbacks = await Feedback.find({ student: req.userId })
      .populate('teacher', 'name department subject')
      .populate('certificate', 'title category')
      .sort({ createdAt: -1 });
    const unread = feedbacks.filter(f => !f.isRead).length;
    res.json({ feedbacks, unreadCount: unread });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Get feedback for a specific student (teacher/admin view)
router.get('/student/:studentId', auth, teacherOrAdmin, async (req, res) => {
  try {
    const feedbacks = await Feedback.find({ student: req.params.studentId })
      .populate('teacher', 'name department')
      .populate('certificate', 'title category')
      .sort({ createdAt: -1 });
    res.json({ feedbacks });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Student marks a feedback as read → teacher can see "Seen ✓" in real time
router.put('/:id/read', auth, async (req, res) => {
  try {
    const feedback = await Feedback.findOne({ _id: req.params.id, student: req.userId });
    if (!feedback) return res.status(404).json({ error: 'Feedback not found' });

    if (!feedback.isRead) {
      feedback.isRead = true;
      await feedback.save();

      // Real-time: notify the teacher that their feedback was read
      const io = req.app.get('io');
      const connectedUsers = req.app.get('connectedUsers');
      if (io && connectedUsers) {
        const teacherSocket = connectedUsers.get(feedback.teacher.toString());
        if (teacherSocket) {
          io.to(teacherSocket).emit('feedback:seen', {
            feedbackId: feedback._id.toString(),
            studentId: req.userId.toString()
          });
        }
      }
    }

    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Student marks ALL feedback as read
router.put('/read-all', auth, async (req, res) => {
  try {
    const unreadFeedbacks = await Feedback.find({ student: req.userId, isRead: false }).select('_id teacher');
    await Feedback.updateMany({ student: req.userId, isRead: false }, { isRead: true });

    // Notify each teacher whose feedback was marked read
    const io = req.app.get('io');
    const connectedUsers = req.app.get('connectedUsers');
    if (io && connectedUsers) {
      const teacherIds = [...new Set(unreadFeedbacks.map(f => f.teacher.toString()))];
      for (const teacherId of teacherIds) {
        const teacherSocket = connectedUsers.get(teacherId);
        if (teacherSocket) {
          const feedbackIds = unreadFeedbacks.filter(f => f.teacher.toString() === teacherId).map(f => f._id.toString());
          io.to(teacherSocket).emit('feedback:seen-all', { feedbackIds, studentId: req.userId.toString() });
        }
      }
    }

    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Teacher deletes a feedback
router.delete('/:id', auth, teacherOrAdmin, async (req, res) => {
  try {
    await Feedback.findOneAndDelete({ _id: req.params.id, teacher: req.userId });
    res.json({ message: 'Deleted' });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
