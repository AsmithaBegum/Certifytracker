const express = require('express');
const router = express.Router();
const User = require('../models/User');
const Certificate = require('../models/Certificate');
const { auth, adminOnly } = require('../middleware/auth');

// Get pending approvals (students and teachers)
router.get('/pending-approvals', auth, adminOnly, async (req, res) => {
  try {
    const pendingUsers = await User.find({ 
      isApproved: false,
      role: { $in: ['student', 'teacher'] }
    })
    .select('-password')
    .sort({ registeredAt: -1 });
    
    res.json({ 
      pendingUsers,
      count: pendingUsers.length
    });
  } catch (error) {
    console.error('Get pending approvals error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Approve user
router.put('/approve/:userId', auth, adminOnly, async (req, res) => {
  try {
    const user = await User.findById(req.params.userId);
    
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    if (user.role === 'admin') {
      return res.status(400).json({ error: 'Cannot modify admin accounts' });
    }
    
    user.isApproved = true;
    await user.save();
    
    res.json({ 
      message: `${user.role} approved successfully`,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        isApproved: user.isApproved
      }
    });
  } catch (error) {
    console.error('Approve user error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Reject user (delete account)
router.delete('/reject/:userId', auth, adminOnly, async (req, res) => {
  try {
    const user = await User.findById(req.params.userId);
    
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    if (user.role === 'admin') {
      return res.status(400).json({ error: 'Cannot delete admin accounts' });
    }
    
    await User.findByIdAndDelete(req.params.userId);
    
    res.json({ message: `${user.role} account rejected and deleted` });
  } catch (error) {
    console.error('Reject user error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Get all users with certificate counts
router.get('/users', auth, adminOnly, async (req, res) => {
  try {
    const { role } = req.query;
    
    let query = { role: { $ne: 'admin' } }; // Exclude admins from list
    
    if (role && (role === 'student' || role === 'teacher')) {
      query.role = role;
    }
    
    const users = await User.find(query)
      .select('-password')
      .sort({ registeredAt: -1 });
    
    // Get certificate counts for students
    const usersWithCounts = await Promise.all(users.map(async (user) => {
      let certificateCount = 0;
      if (user.role === 'student') {
        certificateCount = await Certificate.countDocuments({ student: user._id });
      }
      return {
        ...user.toObject(),
        certificateCount
      };
    }));
    
    res.json({ 
      users: usersWithCounts,
      count: usersWithCounts.length
    });
  } catch (error) {
    console.error('Get users error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Get all students (for teachers - filtered by department)
router.get('/students', auth, async (req, res) => {
  try {
    // Only teachers and admins can access
    if (req.userRole !== 'teacher' && req.userRole !== 'admin') {
      return res.status(403).json({ error: 'Access denied' });
    }
    
    let query = { 
      role: 'student',
      isApproved: true 
    };
    
    // Teachers can only see students from their own department
    // Teacher's department is stored in the 'subject' field OR 'department' field
    // We match teacher's subject/department with student's department
    if (req.userRole === 'teacher') {
      const teacher = req.user;
      // Use teacher's department if set, otherwise use subject as department identifier
      const teacherDepartment = teacher.department || teacher.subject;
      if (teacherDepartment) {
        query.department = { $regex: new RegExp(`^${teacherDepartment}$`, 'i') };
      }
    }
    
    const students = await User.find(query)
      .select('-password')
      .sort({ name: 1 });
    
    // Get certificate counts
    const studentsWithCounts = await Promise.all(students.map(async (student) => {
      const certificateCount = await Certificate.countDocuments({ student: student._id });
      return {
        ...student.toObject(),
        certificateCount
      };
    }));
    
    res.json({ 
      students: studentsWithCounts,
      count: studentsWithCounts.length,
      teacherDepartment: req.userRole === 'teacher' ? (req.user.department || req.user.subject) : null
    });
  } catch (error) {
    console.error('Get students error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Delete user (admins only)
router.delete('/users/:userId', auth, adminOnly, async (req, res) => {
  try {
    const user = await User.findById(req.params.userId);
    
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    if (user.role === 'admin') {
      return res.status(400).json({ error: 'Cannot delete admin accounts' });
    }
    
    // If student, delete all their certificates
    if (user.role === 'student') {
      const certificates = await Certificate.find({ student: user._id });
      
      // Delete certificate files
      const fs = require('fs');
      certificates.forEach(cert => {
        if (fs.existsSync(cert.filePath)) {
          fs.unlinkSync(cert.filePath);
        }
      });
      
      // Delete certificate records
      await Certificate.deleteMany({ student: user._id });
    }
    
    await User.findByIdAndDelete(req.params.userId);
    
    res.json({ message: 'User deleted successfully' });
  } catch (error) {
    console.error('Delete user error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Get dashboard statistics
router.get('/dashboard/stats', auth, adminOnly, async (req, res) => {
  try {
    const totalStudents = await User.countDocuments({ role: 'student', isApproved: true });
    const totalTeachers = await User.countDocuments({ role: 'teacher', isApproved: true });
    const pendingApprovals = await User.countDocuments({ isApproved: false, role: { $in: ['student', 'teacher'] } });
    const totalCertificates = await Certificate.countDocuments();
    
    // Recent activity (last 10 registrations)
    const recentActivity = await User.find({ role: { $in: ['student', 'teacher'] } })
      .select('name role registeredAt isApproved')
      .sort({ registeredAt: -1 })
      .limit(10);
    
    res.json({
      totalStudents,
      totalTeachers,
      pendingApprovals,
      totalCertificates,
      recentActivity
    });
  } catch (error) {
    console.error('Dashboard stats error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
