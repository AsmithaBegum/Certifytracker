const express = require('express');
const router = express.Router();
const {
  getNotifications,
  markAsRead,
  markAllAsRead,
  deleteNotification,
  clearAllNotifications
} = require('../controllers/notificationController');
const { protect, authorize } = require('../middleware/auth');

// All routes are for teachers
router.use(protect);
router.use(authorize('teacher'));

router.get('/', getNotifications);
router.put('/:notificationId/read', markAsRead);
router.put('/read-all', markAllAsRead);
router.delete('/:notificationId', deleteNotification);
router.delete('/clear-all', clearAllNotifications);

module.exports = router;
