const express = require('express');
const router = express.Router();
const Certificate = require('../models/Certificate');
const User = require('../models/User');
const { auth, studentOnly } = require('../middleware/auth');
const { performMLAnalysis } = require('../services/mlService');

// Get ML growth analysis for student
router.get('/growth-analysis', auth, async (req, res) => {
  try {
    let userId = req.userId;
    let userDepartment = req.user.department;
    
    // Teachers can view their own analysis too
    if (req.userRole === 'teacher') {
      // For teachers, we'll analyze if they have any certificates (if system allows teacher uploads)
      // For now, return a message
      return res.status(200).json({
        message: 'ML Growth Analysis is currently available for students only',
        userRole: req.userRole
      });
    }
    
    // Get all certificates for the student
    const certificates = await Certificate.find({ student: userId }).lean();
    
    if (!certificates || certificates.length === 0) {
      return res.status(200).json({
        message: 'No certificates found. Upload certificates to view growth analysis.',
        hasData: false
      });
    }
    
    // Perform ML analysis
    const analysis = performMLAnalysis(certificates, userDepartment);
    
    if (analysis.error) {
      return res.status(200).json(analysis);
    }
    
    res.json({
      hasData: true,
      analysis,
      generatedAt: new Date()
    });
  } catch (error) {
    console.error('ML Analysis error:', error);
    res.status(500).json({ error: 'Server error during ML analysis' });
  }
});

// Get growth analysis for specific student (Teachers/Admins)
router.get('/growth-analysis/:studentId', auth, async (req, res) => {
  try {
    // Only teachers and admins can view other students' analysis
    if (req.userRole !== 'teacher' && req.userRole !== 'admin') {
      return res.status(403).json({ error: 'Access denied' });
    }
    
    const student = await User.findById(req.params.studentId);
    
    if (!student || student.role !== 'student') {
      return res.status(404).json({ error: 'Student not found' });
    }
    
    const certificates = await Certificate.find({ student: req.params.studentId }).lean();
    
    if (!certificates || certificates.length === 0) {
      return res.status(200).json({
        message: 'No certificates found for this student.',
        hasData: false,
        studentName: student.name
      });
    }
    
    const analysis = performMLAnalysis(certificates, student.department);
    
    res.json({
      hasData: true,
      studentName: student.name,
      studentDepartment: student.department,
      analysis,
      generatedAt: new Date()
    });
  } catch (error) {
    console.error('ML Analysis error:', error);
    res.status(500).json({ error: 'Server error during ML analysis' });
  }
});

module.exports = router;
