const axios = require('axios');

// Simulated external API verification (90% success rate)
async function verifyWithExternalAPI(issuer, certificateId, qrCodeData) {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  // 90% success rate
  const isValid = Math.random() < 0.9;
  
  return {
    verified: isValid,
    issuer: issuer,
    certificateId: certificateId,
    verificationDate: new Date(),
    message: isValid 
      ? `Certificate verified successfully with ${issuer}` 
      : `Verification failed - certificate may be invalid`
  };
}

// Main verification function
async function verifyCertificate(certificateData) {
  const { certificateId, issuer, qrCodeData } = certificateData;
  
  let verificationResult = {
    status: 'unverified',
    method: 'none',
    message: 'No verification data provided'
  };
  
  // Priority 1: QR Code verification
  if (qrCodeData && qrCodeData.trim() !== '') {
    try {
      const result = await verifyWithExternalAPI(issuer, certificateId, qrCodeData);
      verificationResult = {
        status: result.verified ? 'verified' : 'unverified',
        method: 'qr_code',
        message: result.message,
        verifiedAt: result.verificationDate
      };
      return verificationResult;
    } catch (error) {
      console.error('QR Code verification error:', error);
    }
  }
  
  // Priority 2: Certificate ID verification
  if (certificateId && certificateId.trim() !== '' && issuer && issuer !== 'Other') {
    try {
      const result = await verifyWithExternalAPI(issuer, certificateId, null);
      verificationResult = {
        status: result.verified ? 'verified' : 'unverified',
        method: 'certificate_id',
        message: result.message,
        verifiedAt: result.verificationDate
      };
      return verificationResult;
    } catch (error) {
      console.error('Certificate ID verification error:', error);
    }
  }
  
  // No automated verification possible
  return verificationResult;
}

// Manual verification by teacher/admin
function manualVerification(verifiedBy) {
  return {
    status: 'verified',
    method: 'manual',
    message: 'Manually verified by administrator or teacher',
    verifiedAt: new Date(),
    verifiedBy: verifiedBy
  };
}

// Get supported issuers
function getSupportedIssuers() {
  return [
    { name: 'Coursera', code: 'coursera' },
    { name: 'Udemy', code: 'udemy' },
    { name: 'LinkedIn', code: 'linkedin' },
    { name: 'Google', code: 'google' },
    { name: 'Microsoft', code: 'microsoft' },
    { name: 'AWS', code: 'aws' },
    { name: 'Other', code: 'other' }
  ];
}

module.exports = {
  verifyCertificate,
  manualVerification,
  getSupportedIssuers
};
