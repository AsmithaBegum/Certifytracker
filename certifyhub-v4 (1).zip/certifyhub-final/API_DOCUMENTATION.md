# CertifyHub API Documentation

## Base URL
```
Development: http://localhost:5000/api
Production: https://yourdomain.com/api
```

## Authentication

All protected endpoints require a JWT token in the Authorization header:
```
Authorization: Bearer <your_jwt_token>
```

---

## 🔐 Authentication Endpoints

### POST /auth/register
Register a new student or teacher account.

**Request Body:**
```json
{
  "name": "John Doe",
  "email": "john@example.com",
  "password": "password123",
  "role": "student",
  "rollNumber": "CS001",  // Required for students
  "department": "Computer Science",  // Required for students
  "subject": "Data Structures"  // Required for teachers
}
```

**Response (201):**
```json
{
  "message": "Registration successful. Please wait for admin approval.",
  "user": {
    "id": "507f1f77bcf86cd799439011",
    "name": "John Doe",
    "email": "john@example.com",
    "role": "student",
    "isApproved": false
  }
}
```

**Errors:**
- 400: Missing required fields
- 400: Email already registered

---

### POST /auth/login
Login to existing account.

**Request Body:**
```json
{
  "email": "john@example.com",
  "password": "password123"
}
```

**Response (200):**
```json
{
  "message": "Login successful",
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": "507f1f77bcf86cd799439011",
    "name": "John Doe",
    "email": "john@example.com",
    "role": "student",
    "department": "Computer Science",
    "rollNumber": "CS001",
    "isApproved": true
  }
}
```

**Errors:**
- 401: Invalid email or password
- 403: Account pending approval (isPending: true)

---

### GET /auth/me
Get current user information.

**Headers:** Authorization required

**Response (200):**
```json
{
  "user": {
    "_id": "507f1f77bcf86cd799439011",
    "name": "John Doe",
    "email": "john@example.com",
    "role": "student",
    "department": "Computer Science",
    "rollNumber": "CS001",
    "isApproved": true,
    "notifications": []
  }
}
```

---

## 📜 Certificate Endpoints

### POST /certificates/upload
Upload a new certificate (Students only).

**Headers:** 
- Authorization required
- Content-Type: multipart/form-data

**Request Body (FormData):**
```
title: "Python for Data Science"
description: "Completed Python programming course"
issueDate: "2024-01-15"
certificate: <file>  // PDF, JPG, or PNG
certificateId: "CERT123" (optional)
issuer: "Coursera" (optional)
qrCodeData: "https://verify.coursera.org/ABC123" (optional)
```

**Response (201):**
```json
{
  "message": "Certificate uploaded successfully",
  "certificate": {
    "_id": "507f1f77bcf86cd799439012",
    "student": "507f1f77bcf86cd799439011",
    "title": "Python for Data Science",
    "description": "Completed Python programming course",
    "issueDate": "2024-01-15T00:00:00.000Z",
    "fileName": "cert-1705334400000-123456789.pdf",
    "fileType": "application/pdf",
    "category": "Programming",
    "keywords": ["python", "data", "science"],
    "skillLevel": "Beginner",
    "verificationStatus": "verified",
    "verificationMethod": "certificate_id",
    "uploadedAt": "2024-02-14T10:00:00.000Z"
  }
}
```

**Errors:**
- 400: No file uploaded
- 400: Missing required fields
- 400: Invalid file type (must be PDF, JPG, or PNG)
- 413: File too large (max 10MB)

---

### GET /certificates/my-certificates
Get all certificates uploaded by current student.

**Headers:** Authorization required (Student only)

**Response (200):**
```json
{
  "certificates": [
    {
      "_id": "507f1f77bcf86cd799439012",
      "title": "Python for Data Science",
      "description": "Completed Python programming",
      "issueDate": "2024-01-15T00:00:00.000Z",
      "fileName": "cert-1705334400000-123456789.pdf",
      "fileType": "application/pdf",
      "category": "Programming",
      "verificationStatus": "verified",
      "uploadedAt": "2024-02-14T10:00:00.000Z"
    }
  ],
  "count": 1
}
```

---

### GET /certificates/all
Get all certificates in the system (Teachers/Admins only).

**Headers:** Authorization required

**Query Parameters:**
- `year` (optional): Filter by issue year (e.g., 2024, 2023)
- `verificationStatus` (optional): "verified", "unverified", or "all"
- `studentId` (optional): Filter by specific student

**Example:**
```
GET /certificates/all?year=2024&verificationStatus=verified
```

**Response (200):**
```json
{
  "certificates": [
    {
      "_id": "507f1f77bcf86cd799439012",
      "student": {
        "_id": "507f1f77bcf86cd799439011",
        "name": "John Doe",
        "rollNumber": "CS001",
        "department": "Computer Science"
      },
      "title": "Python for Data Science",
      "category": "Programming",
      "verificationStatus": "verified",
      "issueDate": "2024-01-15T00:00:00.000Z"
    }
  ],
  "count": 1
}
```

---

### GET /certificates/search
NLP-powered certificate search (Teachers/Admins only).

**Headers:** Authorization required

**Query Parameters:**
- `query`: Search term (e.g., "Python", "React course", "Java backend")
- `year` (optional): Filter by issue year
- `verificationStatus` (optional): Filter by verification status

**Example:**
```
GET /certificates/search?query=Python machine learning&year=2024
```

**Response (200):**
```json
{
  "certificates": [
    {
      "_id": "507f1f77bcf86cd799439012",
      "student": {
        "name": "John Doe",
        "rollNumber": "CS001",
        "department": "Computer Science"
      },
      "title": "Python for Machine Learning",
      "description": "Deep learning and neural networks",
      "category": "AI/ML",
      "keywords": ["python", "machine", "learning"],
      "verificationStatus": "verified"
    }
  ],
  "count": 1,
  "searchQuery": "Python machine learning"
}
```

---

### GET /certificates/download/:id
Download certificate file.

**Headers:** Authorization required

**Parameters:**
- `id`: Certificate ID

**Response:** Binary file download (PDF/JPG/PNG)

**Errors:**
- 404: Certificate not found
- 403: Access denied (students can only download own certificates)
- 404: Certificate file not found on server

---

### DELETE /certificates/:id
Delete a certificate.

**Headers:** Authorization required

**Parameters:**
- `id`: Certificate ID

**Notes:**
- Students can only delete their own certificates
- Admins can delete any certificate

**Response (200):**
```json
{
  "message": "Certificate deleted successfully"
}
```

---

### PUT /certificates/verify/:id
Manually verify a certificate (Teachers/Admins only).

**Headers:** Authorization required

**Parameters:**
- `id`: Certificate ID

**Response (200):**
```json
{
  "message": "Certificate verified successfully",
  "certificate": {
    "_id": "507f1f77bcf86cd799439012",
    "verificationStatus": "verified",
    "verificationMethod": "manual",
    "verifiedBy": "507f1f77bcf86cd799439010",
    "verifiedAt": "2024-02-14T10:30:00.000Z"
  }
}
```

---

## 👥 Admin Endpoints

### GET /admin/pending-approvals
Get all pending user registrations.

**Headers:** Authorization required (Admin only)

**Response (200):**
```json
{
  "pendingUsers": [
    {
      "_id": "507f1f77bcf86cd799439011",
      "name": "John Doe",
      "email": "john@example.com",
      "role": "student",
      "department": "Computer Science",
      "rollNumber": "CS001",
      "isApproved": false,
      "registeredAt": "2024-02-14T09:00:00.000Z"
    },
    {
      "_id": "507f1f77bcf86cd799439013",
      "name": "Jane Smith",
      "email": "jane@example.com",
      "role": "teacher",
      "subject": "Data Structures",
      "isApproved": false,
      "registeredAt": "2024-02-14T09:30:00.000Z"
    }
  ],
  "count": 2
}
```

---

### PUT /admin/approve/:userId
Approve a user registration.

**Headers:** Authorization required (Admin only)

**Parameters:**
- `userId`: User ID to approve

**Response (200):**
```json
{
  "message": "student approved successfully",
  "user": {
    "id": "507f1f77bcf86cd799439011",
    "name": "John Doe",
    "email": "john@example.com",
    "role": "student",
    "isApproved": true
  }
}
```

---

### DELETE /admin/reject/:userId
Reject and delete a user registration.

**Headers:** Authorization required (Admin only)

**Parameters:**
- `userId`: User ID to reject

**Response (200):**
```json
{
  "message": "student account rejected and deleted"
}
```

---

### GET /admin/users
Get all users in the system.

**Headers:** Authorization required (Admin only)

**Query Parameters:**
- `role` (optional): "student", "teacher", or empty for all

**Example:**
```
GET /admin/users?role=student
```

**Response (200):**
```json
{
  "users": [
    {
      "_id": "507f1f77bcf86cd799439011",
      "name": "John Doe",
      "email": "john@example.com",
      "role": "student",
      "department": "Computer Science",
      "rollNumber": "CS001",
      "isApproved": true,
      "certificateCount": 5,
      "registeredAt": "2024-02-14T09:00:00.000Z"
    }
  ],
  "count": 1
}
```

---

### GET /admin/students
Get all approved students (Teachers/Admins).

**Headers:** Authorization required

**Response (200):**
```json
{
  "students": [
    {
      "_id": "507f1f77bcf86cd799439011",
      "name": "John Doe",
      "email": "john@example.com",
      "department": "Computer Science",
      "rollNumber": "CS001",
      "certificateCount": 5
    }
  ],
  "count": 1
}
```

---

### DELETE /admin/users/:userId
Delete a user account.

**Headers:** Authorization required (Admin only)

**Parameters:**
- `userId`: User ID to delete

**Notes:**
- Cannot delete admin accounts
- Deletes all student's certificates if deleting a student

**Response (200):**
```json
{
  "message": "User deleted successfully"
}
```

---

### GET /admin/dashboard/stats
Get dashboard statistics.

**Headers:** Authorization required (Admin only)

**Response (200):**
```json
{
  "totalStudents": 45,
  "totalTeachers": 8,
  "pendingApprovals": 3,
  "totalCertificates": 234,
  "recentActivity": [
    {
      "name": "John Doe",
      "role": "student",
      "registeredAt": "2024-02-14T09:00:00.000Z",
      "isApproved": true
    }
  ]
}
```

---

## 🤖 ML Analysis Endpoints

### GET /ml/growth-analysis
Get ML growth analysis for current student.

**Headers:** Authorization required (Student only)

**Response (200):**
```json
{
  "hasData": true,
  "analysis": {
    "skillLevelScore": 68,
    "careerReadinessScore": 72,
    "careerReadinessBreakdown": {
      "volume": 15,
      "diversity": 16,
      "progression": 20,
      "consistency": 12,
      "specialization": 9
    },
    "predictedRoles": [
      {
        "role": "Full Stack Developer",
        "confidence": 85
      },
      {
        "role": "Backend Developer",
        "confidence": 78
      }
    ],
    "recommendations": [
      {
        "skill": "Cloud Computing",
        "priority": "High",
        "reason": "Critical skill for modern software development",
        "estimatedTime": "3-4 weeks",
        "suggestions": ["AWS Fundamentals", "Docker Basics", "CI/CD Introduction"]
      }
    ],
    "growthChart": [
      {
        "date": "2024-01-15",
        "count": 1,
        "category": "Programming"
      },
      {
        "date": "2024-01-20",
        "count": 2,
        "category": "Backend"
      }
    ],
    "peerComparison": {
      "userCertificates": 10,
      "departmentAverage": 8,
      "topPerformer": 25,
      "percentile": 40,
      "ranking": "Top 50%"
    },
    "features": {
      "totalCertificates": 10,
      "categoryCounts": {
        "Programming": 2,
        "Backend": 3,
        "Frontend": 2,
        "Database": 2,
        "Cloud": 1,
        "AI/ML": 0,
        "Mobile": 0,
        "Other": 0
      },
      "uniqueCategories": 5,
      "averageTimeGap": 12,
      "growthRate": "1.25",
      "monthsActive": 8,
      "skillLevels": {
        "Beginner": 4,
        "Intermediate": 5,
        "Advanced": 1
      }
    }
  },
  "generatedAt": "2024-02-14T10:00:00.000Z"
}
```

**Response (200) - No certificates:**
```json
{
  "message": "No certificates found. Upload certificates to view growth analysis.",
  "hasData": false
}
```

---

### GET /ml/growth-analysis/:studentId
Get ML growth analysis for specific student (Teachers/Admins).

**Headers:** Authorization required

**Parameters:**
- `studentId`: Student ID

**Response:** Same as above, plus:
```json
{
  "hasData": true,
  "studentName": "John Doe",
  "studentDepartment": "Computer Science",
  "analysis": { ... }
}
```

---

## 🔔 Notification Endpoints

### GET /notifications
Get user's notifications.

**Headers:** Authorization required

**Response (200):**
```json
{
  "notifications": [
    {
      "_id": "507f1f77bcf86cd799439020",
      "message": "John Doe uploaded a new certificate: Python for Data Science",
      "certificateId": "507f1f77bcf86cd799439012",
      "studentName": "John Doe",
      "isRead": false,
      "createdAt": "2024-02-14T10:00:00.000Z"
    }
  ],
  "unreadCount": 1
}
```

---

## 🔌 Socket.io Events

### Connection
```javascript
const socket = io('http://localhost:5000');

// Join with user ID
socket.emit('user:join', userId);
```

### Events to Listen

**notification:new** - Receive new notification
```javascript
socket.on('notification:new', ({ notification, unreadCount }) => {
  console.log('New notification:', notification);
  console.log('Unread count:', unreadCount);
});
```

**notification:updated** - Notification marked as read
```javascript
socket.on('notification:updated', ({ notificationId, isRead }) => {
  // Update UI
});
```

**notification:all-read** - All notifications marked as read
```javascript
socket.on('notification:all-read', () => {
  // Update UI
});
```

**notification:deleted** - Notification deleted
```javascript
socket.on('notification:deleted', ({ notificationId }) => {
  // Remove from UI
});
```

### Events to Emit

**notification:read** - Mark notification as read
```javascript
socket.emit('notification:read', { userId, notificationId });
```

**notification:read-all** - Mark all as read
```javascript
socket.emit('notification:read-all', { userId });
```

**notification:delete** - Delete notification
```javascript
socket.emit('notification:delete', { userId, notificationId });
```

---

## 📊 Response Codes

- **200** - Success
- **201** - Created
- **400** - Bad Request (validation error)
- **401** - Unauthorized (no/invalid token)
- **403** - Forbidden (insufficient permissions)
- **404** - Not Found
- **500** - Internal Server Error

---

## 🔒 Role Permissions

| Endpoint | Student | Teacher | Admin |
|----------|---------|---------|-------|
| Upload Certificate | ✅ | ❌ | ❌ |
| View Own Certificates | ✅ | ❌ | ❌ |
| View All Certificates | ❌ | ✅ | ✅ |
| Search Certificates | ❌ | ✅ | ✅ |
| Download Certificate | ✅ (own) | ✅ (all) | ✅ (all) |
| Delete Certificate | ✅ (own) | ❌ | ✅ (all) |
| Verify Certificate | ❌ | ✅ | ✅ |
| View ML Analysis | ✅ (own) | ✅ (all) | ✅ (all) |
| Approve Users | ❌ | ❌ | ✅ |
| Manage Users | ❌ | ❌ | ✅ |
| Dashboard Stats | ❌ | ❌ | ✅ |
| View Students | ❌ | ✅ | ✅ |
| Notifications | ❌ | ✅ | ✅ |

---

## 📝 Notes

1. All dates are in ISO 8601 format
2. File uploads limited to 10MB
3. Supported file types: PDF, JPG, PNG
4. JWT tokens expire after 7 days
5. Passwords are hashed with bcrypt (10 rounds)
6. Socket.io uses WebSocket transport
7. NLP categorization is automatic on upload
8. ML analysis requires at least 1 certificate

---

For more information, see README.md
